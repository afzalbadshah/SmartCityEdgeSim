# core/simulator.py
"""
SmartCityEdgeSimPy — Educational Release

Main simulator. Builds servers/devices, runs scheduler, reports metrics,
and (now) publishes MEC->Metro pairs each round for the GUI.
"""

import math

from entities.server          import Server
from workload.generator       import WorkloadGenerator
from scheduler.base_scheduler import BaseScheduler
from core.reporter            import task_reporter
from mobility.manager         import MobilityManager
from mobility.mobile_entity   import MobileEntity
from mobility.random_waypoint import RandomWaypoint

from collections import Counter, defaultdict

from config.config            import CITY_AREA
from config.config            import SERVER_CONFIG, WORKLOAD, MOBILITY_CONFIG
from config.metrics           import (
    calculate_transmission_delay,
    calculate_propagation_delay,   # mobility-aware (task arg supported)
    calculate_transmission_cost,
    calculate_processing_cost,
    calculate_MEC_energy,
    calculate_Metro_energy,
    calculate_cloud_energy,
    calculate_congestion,
)

# ───────────────────────── helpers ─────────────────────────

def _euclid(ax, ay, bx, by) -> float:
    return math.hypot(float(ax) - float(bx), float(ay) - float(by))

def _nearest_wp_distance(x: float, y: float, servers):
    """Nearest **MEC_** wireless AP and distance; returns (server|None, dist)."""
    wireless = [(s, getattr(s, "x", None), getattr(s, "y", None))
                for s in servers if str(getattr(s, "name", "")).startswith("MEC_")]
    wireless = [(s, sx, sy) for (s, sx, sy) in wireless if sx is not None and sy is not None]
    if not wireless:
        return None, float("inf")
    s, sx, sy = min(wireless, key=lambda t: _euclid(x, y, t[1], t[2]))
    return s, _euclid(x, y, sx, sy)

def _simple_signal_dbm(distance_m: float) -> float:
    d = max(1.0, float(distance_m))
    return max(-100.0, -40.0 - 20.0 * math.log10(d))

def place_servers_in_city(servers):
    """
    Assign x,y to MEC_ / Metro_ / Cloud_ in a simple grid inside CITY_AREA
    if they don't already have explicit positions from SERVER_CONFIG.
    """
    map_servers = [s for s in servers
                   if (s.name.startswith("MEC_") or s.name.startswith("Metro_") or s.name.startswith("Cloud_"))]
    unplaced = [s for s in map_servers if not (hasattr(s, "x") and hasattr(s, "y"))]
    if not unplaced:
        return

    xmin, xmax = CITY_AREA["xmin"], CITY_AREA["xmax"]
    ymin, ymax = CITY_AREA["ymin"], CITY_AREA["ymax"]

    n = len(unplaced)
    cols = math.ceil(math.sqrt(n))
    rows = math.ceil(n / cols)

    xs = [xmin + (i + 0.5) * (xmax - xmin) / cols for i in range(cols)]
    ys = [ymin + (j + 0.5) * (ymax - ymin) / rows for j in range(rows)]

    k = 0
    for j in range(rows):
        for i in range(cols):
            if k >= n:
                break
            s = unplaced[k]
            s.x, s.y = xs[i], ys[j]
            k += 1



class Simulator:
    """
    Orchestrates simulation rounds and integrates a scheduler.
    Publishes gui_links each round for the LiveMap (MEC->Metro pairs).
    """

    def __init__(self, scheduler: BaseScheduler):
        self.scheduler = scheduler
        self.current_time = 0
        self.servers = []
        self.tasks = []
        self.generator = WorkloadGenerator()
        self.gui_links = []  # [{'MEC': 'MEC_1','Metro':'Metro_1','count':N}, ...]

        # Build servers and attach configured coordinates
        self._initialize_servers()
        place_servers_in_city(self.servers)

        # ------------------------- DEVICE ENTITIES SETUP -------------------------
        device_entities = []

        # Spawn ONLY near MEC_* (fallback to all if none)
        MECs = [s for s in self.servers if str(getattr(s, "name", "")).startswith("MEC_")]
        base_list = MECs if MECs else self.servers
        n_base = len(base_list)
        spawn_jitter = float(MOBILITY_CONFIG.get("spawn_jitter", 150.0))

        for i in range(WORKLOAD["max_devices"]):
            srv = base_list[i % n_base]
            init_x = float(getattr(srv, "x", (CITY_AREA["xmin"] + CITY_AREA["xmax"]) * 0.5))
            init_y = float(getattr(srv, "y", (CITY_AREA["ymin"] + CITY_AREA["ymax"]) * 0.5))

            if spawn_jitter > 0:
                import random
                init_x += random.uniform(-spawn_jitter, spawn_jitter)
                init_y += random.uniform(-spawn_jitter, spawn_jitter)

            ent = MobileEntity(
                entity_id=i,
                init_pos=[init_x, init_y],
                speed=MOBILITY_CONFIG.get("default_speed_m_s", 0.0),
            )

            # Seed serving cell strictly to nearest MEC
            serving0, _ = _nearest_wp_distance(init_x, init_y, self.servers)
            ent.attached_server = serving0 if serving0 is not None else srv

            # Random Waypoint controller
            ent.mobility = RandomWaypoint(
                MOBILITY_CONFIG.get("area", CITY_AREA),
                MOBILITY_CONFIG.get("speed_range", (1.0, 5.0)),
                MOBILITY_CONFIG.get("pause_time", (0.0, 2.0)),
            )
            ent.mobility.pos = (init_x, init_y)
            device_entities.append(ent)

        # Mobility manager gets both servers and devices
        self.mobility = MobilityManager(self.servers, device_entities)

    # ───────────────────────────── Setup helpers ─────────────────────────────

    def _initialize_servers(self):
        """Build Server objects from SERVER_CONFIG and attach x,y if provided."""
        self.servers = []
        for tier, spec in SERVER_CONFIG.items():
            count = int(spec.get("num_datacenters", 1))
            positions = spec.get("positions", None)
            for i in range(count):
                srv = Server(
                    name=f"{tier}_{i+1}",
                    index=i,
                    cpu_capacity=spec["cpu"],
                    memory_capacity=spec["memory"],
                    storage_capacity=spec["storage"],
                    bandwidth=spec["bandwidth"],
                    latency=spec["latency"],
                    cost=spec["cost"],
                    tx_cost=spec.get("tx_cost", 0.0),
                )
                srv.available_cpu = srv.cpu_capacity
                srv.available_memory = srv.memory_capacity
                srv.available_storage = srv.storage_capacity
                if positions and i < len(positions):
                    try:
                        srv.x, srv.y = float(positions[i][0]), float(positions[i][1])
                    except Exception:
                        pass
                print(f"Initialized {srv.name} at ({getattr(srv,'x',None)}, {getattr(srv,'y',None)})")
                self.servers.append(srv)

    # ────────────────────────── GUI links helper ──────────────────────────

    def _update_gui_links(self, assignments):
        """
        Build MEC->(Metro|Cloud) pairs for GUI.
        Publishes avg_delay_ms per link and distinct-device counts per tier.
        """
        pairs = Counter()
        dev_ids_by_tier = defaultdict(set)
        link_delay_sum = defaultdict(float)   # (MEC, dest, tier) -> ms
        link_delay_cnt = Counter()            # (MEC, dest, tier) -> n

        for task, srv in assignments:
            sname  = str(getattr(srv, "name", ""))
            ent_id = getattr(task, "entity_id", -1)

            if sname.startswith("Metro"):
                tier = "Metro"
            elif sname.startswith("Cloud"):
                tier = "Cloud"
            elif sname.startswith("MEC"):
                # local service at MEC -> no backhaul arrow, but count device
                dev_ids_by_tier["MEC"].add(ent_id)
                continue
            else:
                continue

            # Serving MEC (wireless AP)
            MEC = str(getattr(task, "wireless_ap", "") or "")
            if not MEC and hasattr(self, "mobility"):
                try:
                    dev = self.mobility.entities[ent_id]
                    ap  = getattr(dev, "attached_server", None)
                    MEC = str(getattr(ap, "name", "") or "")
                except Exception:
                    MEC = ""

            if MEC.startswith("MEC"):
                key = (MEC, sname, tier)
                pairs[key] += 1
                dev_ids_by_tier[tier].add(ent_id)

                # per-task total link delay (ms): TX + propagation (mobility-aware) + handover
                tx_ms   = calculate_transmission_delay(task.data_size_kb, srv.name)
                prop_ms = calculate_propagation_delay(srv.name, task=task)
                ho_ms   = float(getattr(task, "handover_ms", 0.0))
                link_delay_sum[key] += (tx_ms + prop_ms + ho_ms)
                link_delay_cnt[key] += 1

        # publish links (with avg_delay_ms)
        self.gui_links = []
        for (e, d, t), c in pairs.items():
            n = link_delay_cnt[(e, d, t)]
            avg_ms = (link_delay_sum[(e, d, t)] / n) if n else 0.0
            self.gui_links.append({
                "MEC": e, "to": d, "tier": t, "count": c,
                "avg_delay_ms": round(avg_ms, 1),
            })

        # legend counts
        self.gui_tier_counts = {
            "MEC":   len(dev_ids_by_tier["MEC"]),
            "Metro": len(dev_ids_by_tier["Metro"]),
            "Cloud": len(dev_ids_by_tier["Cloud"]),
        }




    # ───────────────────────────────── Main loop ─────────────────────────────────
    def run(self):
        """
        Each round:
          1) Update mobility (handovers, etc.)
          2) Release completed tasks
          3) Generate tasks and attach mobility context
          4) Ask scheduler → (task, server) pairs
          5) Apply allocations
          6) Report metrics
          7) Advance clock (included via HO delays)
        """
        total_rounds = (
            (WORKLOAD["max_devices"] - WORKLOAD["start_devices"]) //
            WORKLOAD["increment"]
        ) + 1

        for round_no in range(1, total_rounds + 1):
            # 1) Mobility update
            ho_count, ho_delay = self.mobility.update_all()
            self.current_time += ho_delay
            mob_metrics = self.mobility.get_metrics()

            # 2) Release resources from finished tasks
            for srv in self.servers:
                srv.release_completed_tasks(self.current_time)

            # 3) Generate tasks and tag with mobility context
            self.tasks = self.generator.generate_tasks(round_no)
            num_devices = len(self.tasks)

            for idx, task in enumerate(self.tasks):
                task.entity_id = idx
                if hasattr(task, "set_round"):
                    task.set_round(round_no)

                dev = self.mobility.entities[idx]
                x, y = dev.get_position()

                serving_bs = getattr(dev, "attached_server", None)
                if serving_bs is None or not (hasattr(serving_bs, "x") and hasattr(serving_bs, "y")):
                    serving_bs, _ = _nearest_wp_distance(x, y, self.servers)

                if serving_bs is not None and hasattr(serving_bs, "x") and hasattr(serving_bs, "y"):
                    dist_bs = _euclid(x, y, serving_bs.x, serving_bs.y)
                else:
                    dist_bs = float(SERVER_CONFIG.get("MEC", {}).get("distance", 2000.0))

                try:
                    sig_db = dev.signal_strength(serving_bs) if serving_bs is not None else _simple_signal_dbm(dist_bs)
                except Exception:
                    sig_db = _simple_signal_dbm(dist_bs)

                ho_ms = float(getattr(dev, "last_handover_ms", 0.0))

                task.wireless_ap = getattr(serving_bs, "name", "")
                task.set_mobility(
                    x=x,
                    y=y,
                    distance_to_bs=dist_bs,
                    signal_dbm=sig_db,
                    handover_ms=ho_ms,
                )

            # 4) Scheduler → assignments
            assignments = self.scheduler.schedule(self.tasks, self.servers, self.current_time)


            # ---- MEC↔MEC collaboration aggregates for this round ----
            name_to_srv = {s.name: s for s in self.servers}
            collab_in = defaultdict(int)          # tasks collaborated into this MEC
            wp_local  = defaultdict(int)          # tasks served by their own WP-MEC
            collab_dist_sum   = defaultdict(float)
            collab_dist_count = defaultdict(int)

            for task, srv in assignments:
                sname = str(getattr(srv, "name", ""))
                if not sname.startswith("MEC"):
                    continue

                wp = str(getattr(task, "wireless_ap", "") or "")
                if not wp:
                    # fall back to mobility attachment if needed
                    try:
                        dev = self.mobility.entities[task.entity_id]
                        ap  = getattr(dev, "attached_server", None)
                        wp  = str(getattr(ap, "name", "") or "")
                    except Exception:
                        wp = ""

                if wp == sname:
                    wp_local[sname] += 1
                else:
                    collab_in[sname] += 1
                    src = name_to_srv.get(wp)
                    if src and hasattr(src, "x") and hasattr(src, "y") and hasattr(srv, "x") and hasattr(srv, "y"):
                        d = _euclid(src.x, src.y, srv.x, srv.y)
                        collab_dist_sum[sname]   += d
                        collab_dist_count[sname] += 1


            # Publish MEC->Metro pairs for GUI
            self._update_gui_links(assignments)

            initial_count  = num_devices
            assigned_count = len(assignments)
            failed_count   = initial_count - assigned_count

            # 5) Remove assigned tasks from pending list
            self.tasks = [t for t in self.tasks if not t.is_assigned()]

            # 6) Mark complete & update server resources
            for task, srv in assignments:
                task.complete(start_time=self.current_time, end_time=self.current_time + srv.latency)


            # 7) Per-server metrics (mobility-aware propagation)
            for srv in self.servers:
                assigned_here = [t for t, s in assignments if s is srv]
                if not assigned_here:
                    continue

                total_data = sum(t.data_size_kb for t in assigned_here)

                tx_delay_ms   = 0.0
                prop_delay_ms = 0.0
                tx_cost       = 0.0
                proc_cost     = 0.0
                energy        = 0.0
                signals       = []
                ap_names      = []
                MEC_Metro_dists = []

                tier = srv.name.split("_")[0]

                for t in assigned_here:
                    sig = getattr(t, "signal_dbm", None)
                    dev_t = self.mobility.entities[t.entity_id]
                    if sig is None:
                        ap_name = getattr(t, "wireless_ap", "")
                        ap_srv = name_to_srv.get(ap_name) if ap_name else None
                        try:
                            if ap_srv is not None:
                                sig = dev_t.signal_strength(ap_srv)   # ✅ serving AP
                            else:
                                sig = _simple_signal_dbm(getattr(t, "distance_to_bs", 1.0))
                        except Exception:
                            sig = _simple_signal_dbm(getattr(t, "distance_to_bs", 1.0))
                    signals.append(sig)

                    tx_delay_ms   += calculate_transmission_delay(t.data_size_kb, srv.name)
                    prop_delay_ms += calculate_propagation_delay(srv.name, task=t)

                    tx_cost   += calculate_transmission_cost(t.data_size_kb, SERVER_CONFIG[tier]["tx_cost"])
                    proc_cost += calculate_processing_cost(t.cpu_demand, srv.cost)

                    if tier == "MEC":
                        energy += calculate_MEC_energy(t.data_size_kb)
                    elif tier == "Metro":
                        energy += calculate_Metro_energy(t.data_size_kb)
                    else:
                        energy += calculate_cloud_energy(t.data_size_kb)

                    ap_name = getattr(t, "wireless_ap", "")
                    if not ap_name:
                        ap = getattr(dev_t, "attached_server", None)
                        ap_name = getattr(ap, "name", "")
                    if not ap_name:
                        dx, dy = dev_t.get_position()
                        ap_fallback, _ = _nearest_wp_distance(dx, dy, self.servers)
                        ap_name = getattr(ap_fallback, "name", "")
                    if ap_name:
                        ap_names.append(ap_name)

                    if tier == "Metro" and ap_name:
                        ap_srv = next((s for s in self.servers if s.name == ap_name), None)
                        if ap_srv is not None and hasattr(ap_srv, "x") and hasattr(ap_srv, "y") \
                           and hasattr(srv, "x") and hasattr(srv, "y"):
                            MEC_Metro_dists.append(_euclid(ap_srv.x, ap_srv.y, srv.x, srv.y))

                wireless_ap = Counter(ap_names).most_common(1)[0][0] if ap_names else ""
                avg_MEC2Metro = round(sum(MEC_Metro_dists) / len(MEC_Metro_dists), 1) if MEC_Metro_dists else ""

                used_cpu     = srv.cpu_capacity     - srv.available_cpu
                used_memory  = srv.memory_capacity  - srv.available_memory
                used_storage = srv.storage_capacity - srv.available_storage
                cpu_util     = round(used_cpu     / srv.cpu_capacity    * 100, 2)
                memory_util  = round(used_memory  / srv.memory_capacity * 100, 2)
                storage_util = round(used_storage / srv.storage_capacity* 100, 2)
                congestion   = calculate_congestion(total_data, srv.bandwidth)

               # base metrics (what you already have)
                metrics = {
                    "round_no": round_no,
                    "devices": initial_count,
                    "workload": total_data,
                    **mob_metrics,
                    "avg_signal": round(sum(signals) / len(signals), 2) if signals else 0.0,
                    "wireless_ap": wireless_ap,
                    "MEC2Metro_m": avg_MEC2Metro,
                    "cpu_util": cpu_util,
                    "memory_util": memory_util,
                    "storage_util": storage_util,
                    "layer": srv.name,
                    "avg_tx":   round(tx_delay_ms   / max(1, len(assigned_here)), 2),  # guard ÷0
                    "avg_prop": round(prop_delay_ms / max(1, len(assigned_here)), 2),
                    "tx_cost":  round(tx_cost,  4),
                    "proc_cost":round(proc_cost,4),
                    "energy":   round(energy,   4),
                    "congestion": congestion,
                    "flag": assigned_here[0].priority if assigned_here else "",
                    "failed": initial_count - len(assignments),
                }

                # decide if this row is an MEC server
                is_MEC = srv.name.startswith("MEC")  # or: (_tier_of(srv) == "MEC")

                if is_MEC:
                    eci = collab_in.get(srv.name, 0)      # collaborated into this MEC (computed earlier)
                    ewp = wp_local.get(srv.name, 0)       # served by own WP-MEC
                    denom = (eci + ewp) or 1
                    ratio = round(eci / denom, 3)

                    if collab_dist_count.get(srv.name, 0) > 0:
                        avg_collab_d = round(collab_dist_sum[srv.name] / collab_dist_count[srv.name], 1)
                    else:
                        avg_collab_d = ""

                    metrics.update({
                        "MEC_collab_in":    eci,
                        "MEC_wp_local":     ewp,
                        "MEC_collab_ratio": ratio,
                        "MEC_collab_dist_m": avg_collab_d,
                    })
                else:
                    # keep Reporter happy: always provide the same keys
                    metrics.update({
                        "MEC_collab_in":    "",
                        "MEC_wp_local":     "",
                        "MEC_collab_ratio": "",
                        "MEC_collab_dist_m": "",
                    })

                task_reporter.report(metrics)
