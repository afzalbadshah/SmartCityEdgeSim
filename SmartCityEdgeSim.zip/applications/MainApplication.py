# applications/MainApplication.py
import os, sys
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.abspath(os.path.join(CURRENT_DIR, '..'))
if ROOT_DIR not in sys.path: sys.path.append(ROOT_DIR)

from scheduler.mec_scheduler import MetroScheduler
from core.simulator import Simulator
from live.live_map import LiveMap

def main(): 
    scheduler = MetroScheduler()
    scheduler.set_train_mode(False)      # True=training, False=deployment
    print(f"Launching SmartCityEdgeSimPy with {scheduler.__class__.__name__} ...")
 
    simulator = Simulator(scheduler=scheduler)

    # Do NOT start simulator here. The LiveMap shows SETUP mode first,
    # lets the user drag servers, and starts the sim when Start is clicked.
    gui = LiveMap(simulator, refresh_ms=100)
    gui.start()

if __name__ == "__main__":
    main()
