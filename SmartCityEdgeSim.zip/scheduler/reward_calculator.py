import random
from .server_utils import util_score, _tier_of
from config.metrics import (
    calculate_transmission_cost,
    calculate_processing_cost,
    calculate_propagation_delay
)

class RewardCalculator:
    def __init__(self, servers_list, util_threshold=70.0, cap_high=80.0):
        self.servers_list = servers_list
        self.util_threshold = util_threshold
        self.cap_high = cap_high
        
    def _prop_s(self, name: str, task) -> float:
        return float(calculate_propagation_delay(name, task)) / 1000.0
        
    def _energy_for(self, task, sv):
        from config.metrics import calculate_MEC_energy, calculate_Metro_energy, calculate_cloud_energy
        t = _tier_of(sv)
        if t == "MEC":  return calculate_MEC_energy(task.data_size_kb)
        if t == "Metro": return calculate_Metro_energy(task.data_size_kb)
        return calculate_cloud_energy(task.data_size_kb)
    
    def calculate_reward(self, task, sv_idx):
        """Calculate reward for placement decision"""
        sv = self.servers_list[sv_idx]
        tier = _tier_of(sv)

        cpu, _, mem = sv.utilization()
        cong = sv.congestion()
        tx = getattr(sv, "tx_cost", sv.cost)

        delay = self._prop_s(sv.name, task)
        cost = calculate_processing_cost(task.cpu_demand, sv.cost) + calculate_transmission_cost(task.data_size_kb, tx)
        energy = self._energy_for(task, sv)

        # Reward components
        D = 10 if delay < 0.020 else (5 if delay < 0.026 else -10)
        C = 10 if cost < 3.0 else (5 if cost < 7.5 else -10)
        G = 10 if cong < 8 else (5 if cong < 12 else -10)
        E = 10 if energy < 6 else (5 if energy < 14 else -10)
        Uc = util_score(cpu)
        Um = util_score(mem)

        # Hierarchy shaping
        hier = self._calculate_hierarchy_bonus(tier, task)
        
        # Over-utilization penalty
        over_pen = self._calculate_overutilization_penalty(cpu, mem)

        base = 0.25*D + 0.20*C + 0.15*G + 0.10*E + 0.15*Uc + 0.15*Um
        return max(-8.0, min(8.0, base + hier + over_pen)) / 4.0
    
    def _calculate_hierarchy_bonus(self, tier, task):
        """Calculate hierarchy-based bonus/penalty"""
        if tier == "Cloud":
            any_Metro_free = any(
                (_tier_of(s) == "Metro") and s.can_allocate(task.cpu_demand, task.storage_demand, task.memory_demand)
                for s in self.servers_list
            )
            return -6.0 if any_Metro_free else 2.0
        elif tier == "Metro":
            wp = str(getattr(task, "wireless_ap", "") or "")
            MEC = next((s for s in self.servers_list if s.name == wp), None)
            if MEC is not None:
                e_cpu, _, e_mem = MEC.utilization()
                if max(e_cpu, e_mem) >= (self.util_threshold - 2.0):
                    return 3.0
        return 0.0
    
    def _calculate_overutilization_penalty(self, cpu, mem):
        """Calculate over-utilization penalty"""
        over = max(0.0, cpu - self.cap_high) + max(0.0, mem - self.cap_high)
        return -0.8 * over