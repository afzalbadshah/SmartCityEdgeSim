# scheduler/ppo_model.py
import torch
import torch.nn as nn

class ActorCritic(nn.Module):
    """
    Policy: 3 logits [MECCollab, PEaaS, Cloud] + value head.
    Input dim expects 8 features per server (cpu, mem, cong, cost, delay, energy, d_norm, near_flag).
    """
    def __init__(self, input_dim: int, hidden: int = 64):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, hidden), nn.ReLU(),
            nn.Linear(hidden, hidden),    nn.ReLU(),
        )
        self.pi_head = nn.Linear(hidden, 3)   # MECCollab, PEaaS, Cloud
        self.v_head  = nn.Linear(hidden, 1)

    def forward(self, x):
        z = self.encoder(x)
        pi  = self.pi_head(z)            # [B, 3] logits
        val = self.v_head(z).squeeze(-1) # [B]
        # NEW: softly bound the critic so V doesn't explode
        val = torch.tanh(val) * 5.0
        return pi, val

