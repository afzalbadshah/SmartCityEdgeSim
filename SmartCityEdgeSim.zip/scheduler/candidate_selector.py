# scheduler/candidate_selector.py
import math
import random
from config.config import CITY_AREA
from config.metrics import calculate_propagation_delay
from .server_utils import _tier_of

class CandidateSelector:
    def __init__(self, servers_list):
        self.servers_list = servers_list

    def _dist_wp_to_server(self, task, sv) -> float:
        """Euclidean distance from the task's WP-MEC to the server."""
        wp = str(getattr(task, "wireless_ap", "") or "")
        if not wp:
            return 0.0
        MEC = next((s for s in self.servers_list if s.name == wp), None)
        if MEC is None or not hasattr(MEC, "x") or not hasattr(MEC, "y"):
            return 0.0
        if not hasattr(sv, "x") or not hasattr(sv, "y"):
            return 0.0
        return math.hypot(float(MEC.x) - float(sv.x), float(MEC.y) - float(sv.y))

    def _prop_s(self, name: str, task) -> float:
        return float(calculate_propagation_delay(name, task)) / 1000.0

    def _post_util(self, sv, task):
        """Projected CPU/MEM utilization (%) if we place 'task' on server sv."""
        used_cpu = sv.cpu_capacity - sv.available_cpu
        used_mem = sv.memory_capacity - sv.available_memory
        cpu_after = (used_cpu + task.cpu_demand) / max(1e-6, sv.cpu_capacity) * 100.0
        mem_after = (used_mem + getattr(task, "memory_demand", task.cpu_demand)) / max(1e-6, sv.memory_capacity) * 100.0
        return cpu_after, mem_after

    # ---------- Existing Metro/Cloud helpers ----------
    def _nearest_Metro_order(self, Metro_idxs, task):
        pairs = []
        for i in Metro_idxs:
            d = self._dist_wp_to_server(task, self.servers_list[i])
            if d > 0.0:
                pairs.append((d, i))
        if pairs:
            pairs.sort(key=lambda t: t[0])
            return [i for _, i in pairs]
        pairs = [(self._prop_s(self.servers_list[i].name, task), i) for i in Metro_idxs]
        pairs.sort(key=lambda t: t[0])
        return [i for _, i in pairs]

    def _nearest_cloud_order(self, cloud_idxs, task):
        pairs = [(self._prop_s(self.servers_list[i].name, task), i) for i in cloud_idxs]
        pairs.sort(key=lambda t: t[0])
        return [i for _, i in pairs]

    def _get_feasible_servers(self, indices, task, cap_high, topk, ordering_func):
        primary, secondary = [], []
        for i in ordering_func(indices, task):
            if len(primary) >= topk:
                break
            sv = self.servers_list[i]
            if sv.can_allocate(task.cpu_demand, task.storage_demand, task.memory_demand):
                cpu_after, mem_after = self._post_util(sv, task)
                if max(cpu_after, mem_after) <= cap_high:
                    primary.append(i)
                elif max(cpu_after, mem_after) <= cap_high + 10.0:
                    secondary.append(i)
        return primary if primary else secondary

    def get_feasible_candidates(self, task, P_idx, C_idx, cap_high, topk_Metro=6, topk_cloud=2):
        """(Kept for compatibility) Return feasible Metro and Cloud candidates."""
        allowP = self._get_feasible_servers(P_idx, task, cap_high, topk_Metro, self._nearest_Metro_order)
        allowC = self._get_feasible_servers(C_idx, task, cap_high, topk_cloud, self._nearest_cloud_order)
        return allowP, allowC

    # ---------- NEW: MEC-collaboration + 3-tier getter ----------
    def _nearest_MEC_order(self, MEC_idxs, task):
        """Order *other* MECs by distance from the task's WP-MEC."""
        wp = str(getattr(task, "wireless_ap", "") or "")
        pairs = []
        for i in MEC_idxs:
            sv = self.servers_list[i]
            if sv.name == wp:  # skip the WP-MEC itself (tried elsewhere)
                continue
            d = self._dist_wp_to_server(task, sv)
            if d > 0.0:
                pairs.append((d, i))
        pairs.sort(key=lambda t: t[0])
        return [i for _, i in pairs]

    def _get_feasible_servers_generic(self, indices, task, cap_high, topk, ordering_func):
        primary, secondary = [], []
        for i in ordering_func(indices, task):
            if len(primary) >= topk:
                break
            sv = self.servers_list[i]
            if sv.can_allocate(task.cpu_demand, task.storage_demand, task.memory_demand):
                cpu_after, mem_after = self._post_util(sv, task)
                if max(cpu_after, mem_after) <= cap_high:
                    primary.append(i)
                elif max(cpu_after, mem_after) <= cap_high + 10.0:
                    secondary.append(i)
        return primary if primary else secondary

    def get_feasible_MECs_Metro_cloud(self, task, E_idx, P_idx, C_idx, cap_high,
                                       topk_MEC=3, topk_Metro=6, topk_cloud=2):
        """Return three ordered feasible lists: (MECs, Metro, Cloud)."""
        allowE = self._get_feasible_servers_generic(E_idx, task, cap_high, topk_MEC,  self._nearest_MEC_order)
        allowP = self._get_feasible_servers_generic(P_idx, task, cap_high, topk_Metro, self._nearest_Metro_order)
        allowC = self._get_feasible_servers_generic(C_idx, task, cap_high, topk_cloud, self._nearest_cloud_order)
        return allowE, allowP, allowC
    
    # Add INSIDE CandidateSelector class

def _nearest_MEC_order(self, MEC_idxs, task):
    """Order other MECs by distance from the task's WP-MEC (skip the WP-MEC itself)."""
    wp = str(getattr(task, "wireless_ap", "") or "")
    pairs = []
    for i in MEC_idxs:
        sv = self.servers_list[i]
        if sv.name == wp:
            continue
        d = self._dist_wp_to_server(task, sv)
        if d > 0.0:
            pairs.append((d, i))
    pairs.sort(key=lambda t: t[0])
    return [i for _, i in pairs]

def _get_feasible_servers_generic(self, indices, task, cap_high, topk, ordering_func):
    primary, secondary = [], []
    for i in ordering_func(indices, task):
        if len(primary) >= topk: break
        sv = self.servers_list[i]
        if sv.can_allocate(task.cpu_demand, task.storage_demand, task.memory_demand):
            cpu_after, mem_after = self._post_util(sv, task)
            util_after = max(cpu_after, mem_after)
            if util_after <= cap_high:            primary.append(i)
            elif util_after <= cap_high + 10.0:   secondary.append(i)
    return primary if primary else secondary

def get_feasible_MECs_Metro_cloud(self, task, E_idx, P_idx, C_idx, cap_high,
                                   topk_MEC=3, topk_Metro=6, topk_cloud=2):
    allowE = self._get_feasible_servers_generic(E_idx, task, cap_high, topk_MEC,  self._nearest_MEC_order)
    allowP = self._get_feasible_servers_generic(P_idx, task, cap_high, topk_Metro, self._nearest_Metro_order)
    allowC = self._get_feasible_servers_generic(C_idx, task, cap_high, topk_cloud, self._nearest_cloud_order)
    return allowE, allowP, allowC

