def _tier_of(sv) -> str:
    n = str(getattr(sv, "name", ""))
    if n.startswith("MEC"):  return "MEC"
    if n.startswith("Metro"): return "Metro"
    if n.startswith("Cloud"): return "Cloud"
    return "Other"

def _safe_idx(name: str, default=9999) -> int:
    try: return int(str(name).split("_", 1)[1])
    except Exception: return default

def util_score(u: float) -> float:
    if u < 50.0: return 0.0
    if u < 60.0: return 5.0
    if u < 70.0: return 10.0
    if u < 80.0: return -10.0
    if u < 90.0: return -20.0
    return -30.0

def _order_servers(servers):
    E = sorted([s for s in servers if _tier_of(s) == "MEC"],  key=lambda s: _safe_idx(s.name))
    P = sorted([s for s in servers if _tier_of(s) == "Metro"], key=lambda s: _safe_idx(s.name))
    C = sorted([s for s in servers if _tier_of(s) == "Cloud"], key=lambda s: _safe_idx(s.name))
    return E + P + C