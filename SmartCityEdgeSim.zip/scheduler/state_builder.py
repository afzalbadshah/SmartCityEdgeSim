# scheduler/state_builder.py
import math
from config.config import CITY_AREA
from config.metrics import (
    calculate_transmission_cost,
    calculate_processing_cost,
    calculate_MEC_energy,
    calculate_Metro_energy,
    calculate_cloud_energy,
)
try:
    from .server_utils import _tier_of
except Exception:
    from scheduler.server_utils import _tier_of

class StateBuilder:
    def __init__(self, servers_list, candidate_selector):
        self.servers_list = servers_list
        self.selector = candidate_selector

    def _energy_for(self, task, sv):
        t = _tier_of(sv)
        if t == "MEC":  return calculate_MEC_energy(task.data_size_kb)
        if t == "Metro": return calculate_Metro_energy(task.data_size_kb)
        return calculate_cloud_energy(task.data_size_kb)

    def build_state(self, task, P_idx):
        """
        Build a flat feature vector for ALL servers:
        [cpu, mem, cong, cost, delay_s, energy, d_norm, near_flag] per-server
        with 'd_norm' & 'near_flag' defined for Metro and MEC (collab) servers.
        """
        # nearest Metro index
        orderP = self.selector._nearest_Metro_order(P_idx, task) if P_idx else []
        nearestP = orderP[0] if orderP else -1

        # nearest other MEC index (collab candidate)
        allE = [i for i, sv in enumerate(self.servers_list) if _tier_of(sv) == "MEC"]
        orderE = self.selector._nearest_MEC_order(allE, task) \
                 if hasattr(self.selector, "_nearest_MEC_order") else []
        nearestE = orderE[0] if orderE else -1

        dx = float(CITY_AREA["xmax"] - CITY_AREA["xmin"])
        dy = float(CITY_AREA["ymax"] - CITY_AREA["ymin"])
        diag = max(1.0, math.hypot(dx, dy))

        feats = []
        for idx, sv in enumerate(self.servers_list):
            cpu, _, mem = sv.utilization()
            cong = sv.congestion()

            tx_cost = getattr(sv, "tx_cost", sv.cost)
            cost = calculate_processing_cost(task.cpu_demand, sv.cost) + \
                   calculate_transmission_cost(task.data_size_kb, tx_cost)

            delay_s = self.selector._prop_s(sv.name, task)
            energy  = self._energy_for(task, sv)

            tier = _tier_of(sv)
            if tier in ("Metro", "MEC"):
                d = self.selector._dist_wp_to_server(task, sv) / diag
                d = max(0.0, min(1.0, d))
                near_flag = 1.0 if ((tier == "Metro" and idx == nearestP) or
                                    (tier == "MEC"  and idx == nearestE)) else 0.0
            else:
                d, near_flag = 0.0, 0.0

            feats.extend([cpu, mem, cong, cost, delay_s, energy, d, near_flag])

        return feats
