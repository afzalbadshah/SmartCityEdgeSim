# scheduler/ppo_logger.py
import os, csv
from typing import List, Tuple, Optional

class PPOLogger:
    """CSV + plots for PPO training. Only used in training mode."""
    def __init__(self, out_dir: str = "results", enable_plots: bool = True, enable_csv: bool = True, verbose: bool = True):
        self.out_dir = out_dir
        self.enable_plots = enable_plots
        self.enable_csv = enable_csv
        self.verbose = verbose
        os.makedirs(out_dir, exist_ok=True)
        self.csv_path = os.path.join(out_dir, "ppo_training_log.csv")
        if enable_csv and not os.path.isfile(self.csv_path):
            with open(self.csv_path, "w", newline="") as f:
                w = csv.writer(f)
                w.writerow(["episode","ppo_updates","buffer_len","avg_reward","mec_ratio","regional_ratio","cloud_ratio","actor_loss","critic_loss"]) 

    def log_episode(self, episode: int, updates: int, buffer_len: int, avg_reward: float,
                    action_ratios: Tuple[float,float,float],
                    actor_loss: Optional[float], critic_loss: Optional[float], training: bool):
        if self.verbose:
            print(f"[PPO] ep={episode:5d} upd={updates:3d} buf={buffer_len:4d} avgR={avg_reward:7.3f} actions={action_ratios}")
        if training and self.enable_csv:
            with open(self.csv_path, "a", newline="") as f:
                w = csv.writer(f)
                w.writerow([episode, updates, buffer_len, avg_reward, action_ratios[0], action_ratios[1], action_ratios[2],
                            actor_loss if actor_loss is not None else "", critic_loss if critic_loss is not None else ""]) 

    def export_plots(self, avg_rewards: List[float], action_distribution: List[Tuple[float,float,float]],
                     actor_losses: List[float], critic_losses: List[float]):
        if not self.enable_plots:
            return {}
        import matplotlib.pyplot as plt
        paths = {}

        # Action distribution
        mec = [a[0] for a in action_distribution]
        reg = [a[1] for a in action_distribution]
        cld = [a[2] for a in action_distribution]
        plt.figure()
        plt.stackplot(range(len(mec)), mec, reg, cld, labels=["MEC","Regional","Cloud"])
        plt.title("Action Distribution Over Time"); plt.xlabel("Episodes"); plt.ylabel("Action Ratio")
        plt.legend(loc="lower center")
        p1 = os.path.join(self.out_dir, "action_distribution.png"); plt.savefig(p1, bbox_inches="tight"); plt.close()
        paths["action_distribution"] = p1

        # Average reward
        plt.figure(); plt.plot(avg_rewards)
        plt.title("Average Reward per Episode"); plt.xlabel("Episodes"); plt.ylabel("Average Reward")
        p2 = os.path.join(self.out_dir, "average_reward.png"); plt.savefig(p2, bbox_inches="tight"); plt.close()
        paths["average_reward"] = p2

        # Losses
        plt.figure(); plt.plot(actor_losses, label="Actor Loss"); plt.plot(critic_losses, label="Critic Loss")
        plt.title("Loss Convergence"); plt.xlabel("Updates"); plt.ylabel("Loss"); plt.legend()
        p3 = os.path.join(self.out_dir, "loss_convergence.png"); plt.savefig(p3, bbox_inches="tight"); plt.close()
        paths["loss_convergence"] = p3
        return paths
