# scheduler/Metro_scheduler.py
# -----------------------------------------------------------------------------
# Deterministic WP-MEC first; if it fails, PPO chooses among:
#   0 = MEC collaboration (nearest feasible other MEC)
#   1 = Metro (Regional)
#   2 = Cloud
#
# Training is stabilized with:
# - Train/act masking consistency + logit clamping
# - Advantage normalization + clamp
# - Huber (SmoothL1) critic loss with value_coef
# - Gradient clipping + small weight decay
# - Soft bound on critic is done in ppo_model.py (tanh * 5.0)
# - K_epochs=1 by default
# -----------------------------------------------------------------------------

import os
import random
import torch
import torch.nn as nn
import torch.optim as optim

# Robust imports so this works both as a package and as a script
try:
    from .ppo_model import ActorCritic
    from .server_utils import _order_servers, _tier_of
    from .candidate_selector import CandidateSelector
    from .state_builder import StateBuilder
    from .reward_calculator import RewardCalculator
    from .ppo_logger import PPOLogger
    from scheduler.base_scheduler import BaseScheduler
except Exception:
    from scheduler.ppo_model import ActorCritic
    from scheduler.server_utils import _order_servers, _tier_of
    from scheduler.candidate_selector import CandidateSelector
    from scheduler.state_builder import StateBuilder
    from scheduler.reward_calculator import RewardCalculator
    from scheduler.ppo_logger import PPOLogger
    from scheduler.base_scheduler import BaseScheduler


class MetroScheduler(BaseScheduler):
    def __init__(self,
                 buffer_threshold: int = 128,
                 lr: float = 1e-4,
                 hidden: int = 64,
                 use_ppo_for_decision: bool = True,
                 results_dir: str = "results"):
        super().__init__()

        # ---- PPO / training knobs ----
        self.gamma = 0.99
        self.K_epochs = 1                    # fewer replays per batch → stabler
        self.entropy_coef = 0.005            # gentle regularization
        self.value_coef = 0.5                # downweight critic in total loss
        self.buffer_threshold = int(buffer_threshold)
        self.use_ppo_for_decision = bool(use_ppo_for_decision)

        # ---- Stability knobs ----
        self.grad_clip = 0.5                 # global grad norm clip
        self.logit_clip = 20.0               # clamp valid logits to [-20, 20]
        self.adv_clip = 5.0                  # clamp normalized advantages

        # ---- Capacity / selection knobs ----
        self.util_threshold = 70.0
        self.cap_low = 70.0
        self.cap_high = 80.0
        self.topk_Metro = 6
        self.topk_cloud = 2

        # ---- Mode / exploration ----
        self.training_mode = True
        self.eps_explore = 0.20              # small ε on top of stochastic policy

        # ---- Modules ----
        self.candidate_selector = None
        self.state_builder = None
        self.reward_calculator = None

        # ---- Model / optimizer are created AFTER servers_list is known ----
        self.model = None
        self.optim = None
        self.value_loss = nn.SmoothL1Loss()  # Huber critic
        self._input_dim = None               # track current input-dim to re-init if needed

        # ---- Buffers / state ----
        self.buffer = []                     # list of (state, action_grp, reward, mask)
        self.servers_list = []
        self.model_path = "ppo_Metro_model.pth"

        # ---- Logger ----
        self.logger = PPOLogger(out_dir=results_dir, enable_plots=True, enable_csv=True, verbose=True)
        self.episode_idx = 0
        self.ppo_updates = 0
        self.last_actor_loss = None
        self.last_critic_loss = None

        # Histories for plots
        self._avg_rewards_hist = []
        self._action_ratios_hist = []
        self._actor_losses_hist = []
        self._critic_losses_hist = []

        # Store lr so _ensure_model can build optimizer
        self._lr = float(lr)

    # -------------------------------------------------------------------------
    #                         Model / tier helpers
    # -------------------------------------------------------------------------
    def _ensure_model(self):
        """
        Create or refresh the ActorCritic model + optimizer once servers_list is known.
        Re-initializes if the number of servers (thus input_dim) changes.
        """
        N = len(self.servers_list)
        if N <= 0:
            return
        input_dim = 8 * N  # matches StateBuilder feature width

        needs_init = (self.model is None) or (self._input_dim != input_dim)
        if needs_init:
            self.model = ActorCritic(input_dim=input_dim, hidden=64)
            self.optim = optim.Adam(self.model.parameters(), lr=self._lr, weight_decay=1e-5)
            self._input_dim = input_dim

            # Best-effort load (ignore if shape mismatch / different head)
            if os.path.isfile(self.model_path):
                try:
                    state = torch.load(self.model_path, map_location="cpu")
                    self.model.load_state_dict(state)
                except Exception:
                    # start fresh if incompatible
                    pass

    def _indices_by_tier(self):
        E = [i for i, s in enumerate(self.servers_list) if _tier_of(s) == "MEC"]
        P = [i for i, s in enumerate(self.servers_list) if _tier_of(s) == "Metro"]
        C = [i for i, s in enumerate(self.servers_list) if _tier_of(s) == "Cloud"]
        return E, P, C

    def _post_util(self, sv, task):
        used_cpu = sv.cpu_capacity - sv.available_cpu
        used_mem = sv.memory_capacity - sv.available_memory
        cpu_after = (used_cpu + task.cpu_demand) / max(1e-6, sv.cpu_capacity) * 100.0
        mem_after = (used_mem + getattr(task, "memory_demand", task.cpu_demand)) / max(1e-6, sv.memory_capacity) * 100.0
        return cpu_after, mem_after

    # -------------------------------------------------------------------------
    #                             Placement steps
    # -------------------------------------------------------------------------
    def _try_MEC_placement(self, task, name_to_idx, current_time, assignments):
        """
        Deterministic step 1: place on the task's WP-MEC if feasible under cap_high.
        """
        wp = str(getattr(task, "wireless_ap", "") or "")
        ei = name_to_idx.get(wp, None)
        if ei is None:
            return False
        e = self.servers_list[ei]
        if not e.can_allocate(task.cpu_demand, task.storage_demand, task.memory_demand):
            return False
        cpu_after, mem_after = self._post_util(e, task)
        if max(cpu_after, mem_after) > self.cap_high:
            return False

        e.allocate(task.id, task.cpu_demand, task.storage_demand, task.memory_demand, current_time + e.latency)
        # If your Task.set_server signature is (name, time), pass both here.
        task.set_server(e.name)
        assignments.append((task, e))
        return True

    def _choose_action3(self, state, allowE, allowP, allowC):
        """
        Pick among 3 groups when WP-MEC fails:
          0 = MECCollab, 1 = Metro, 2 = Cloud

        `allowE`, `allowP`, `allowC` are lists of feasible indices (empty = not allowed).
        We apply the same availability mask used in training and clamp ONLY the valid logits.
        Includes small ε-greedy exploration over valid actions.
        """
        valid_actions = []
        if allowE: valid_actions.append(0)
        if allowP: valid_actions.append(1)
        if allowC: valid_actions.append(2)
        if not valid_actions:
            return 2  # safety

        if self.training_mode and (len(valid_actions) > 1) and (random.random() < self.eps_explore):
            return random.choice(valid_actions)

        self.model.train(self.training_mode)
        with torch.no_grad():
            logits3, _ = self.model(torch.FloatTensor([state]))  # [1,3]
        logits3 = logits3[0]  # [3]

        # Build mask on same device
        m = torch.tensor(
            [bool(allowE), bool(allowP), bool(allowC)],
            dtype=torch.bool,
            device=logits3.device
        )

        # Mask invalid & clamp valid logits
        logits3 = logits3.clone()
        logits3[~m] = -1e9
        logits3[m] = logits3[m].clamp(-self.logit_clip, self.logit_clip)

        dist = torch.distributions.Categorical(logits=logits3)
        action = int(dist.sample().item())
        if action not in valid_actions:
            action = random.choice(valid_actions)
        return action

    # -------------------------------------------------------------------------
    #                              PPO training
    # -------------------------------------------------------------------------
    def _train_ppo(self):
        """
        A2C-style update with mask, advantage norm+clamp, grad clip, Huber critic.
        Buffer contains (state, action_grp, reward, mask3).
        """
        if not self.buffer:
            return None, None

        states, acts, rews, masks = zip(*self.buffer)
        S = torch.FloatTensor(states)                 # [B, feat]
        A = torch.LongTensor(acts)                    # [B]
        R = torch.FloatTensor(rews)                   # [B]
        M = torch.FloatTensor(masks)                  # [B, 3] binary mask

        last_actor = last_critic = None
        for _ in range(self.K_epochs):
            logits, values = self.model(S)            # [B,3], [B]

            # Re-apply availability mask; clamp only valid logits
            logits = logits.masked_fill(M == 0, -1e9)
            logits = torch.where(M.bool(), logits.clamp(-self.logit_clip, self.logit_clip), logits)

            dist = torch.distributions.Categorical(logits=logits)
            logp = dist.log_prob(A)                   # [B]

            # Advantage: normalize + clamp
            adv = R - values.detach()
            adv = (adv - adv.mean()) / (adv.std() + 1e-8)
            adv = torch.clamp(adv, -self.adv_clip, self.adv_clip)

            actor_loss  = -(logp * adv).mean() - self.entropy_coef * dist.entropy().mean()
            critic_loss = self.value_loss(values, R)
            loss = actor_loss + self.value_coef * critic_loss

            self.optim.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.grad_clip)
            self.optim.step()

            last_actor  = float(actor_loss.item())
            last_critic = float(critic_loss.item())

        self.buffer.clear()
        torch.save(self.model.state_dict(), self.model_path)
        self.ppo_updates += 1
        return last_actor, last_critic

    def set_train_mode(self, is_training: bool):
        self.training_mode = bool(is_training)
        self.eps_explore = 0.20 if self.training_mode else 0.0
        if not self.training_mode:
            self.buffer.clear()

    # -------------------------------------------------------------------------
    #                                 Main API
    # -------------------------------------------------------------------------
    def schedule(self, tasks, servers, current_time):
        """
        One schedule() call is treated as an episode for logging.
        Step 1: try WP-MEC deterministically.
        Step 2: if it fails, PPO picks among MECCollab / Metro / Cloud.
        """
        # Refresh server view and model
        self.servers_list = _order_servers(servers)
        self._ensure_model()

        # Lazy-init helpers
        if self.candidate_selector is None:
            self.candidate_selector = CandidateSelector(self.servers_list)
        if self.state_builder is None:
            self.state_builder = StateBuilder(self.servers_list, self.candidate_selector)
        if self.reward_calculator is None:
            self.reward_calculator = RewardCalculator(self.servers_list, self.util_threshold, self.cap_high)

        assignments = []
        E_idx, P_idx, C_idx = self._indices_by_tier()
        name_to_idx = {s.name: i for i, s in enumerate(self.servers_list)}

        # Episode stats
        cnt_MEC_wp = 0
        cnt_MEC_collab = 0
        cnt_Metro = 0
        cnt_cloud = 0
        sum_reward = 0.0
        n_reward = 0

        for task in tasks:
            # ---- 1) WP-MEC first ----
            if self._try_MEC_placement(task, name_to_idx, current_time, assignments):
                cnt_MEC_wp += 1
                sv_idx = name_to_idx.get(task.server, None) if hasattr(task, "server") else None
                if sv_idx is not None:
                    sum_reward += self.reward_calculator.calculate_reward(task, sv_idx)
                    n_reward += 1
                continue

            # ---- 2) Build 3 candidate sets ----
            allowE, allowP, allowC = self.candidate_selector.get_feasible_MECs_Metro_cloud(
                task, E_idx, P_idx, C_idx, self.cap_high,
                topk_MEC=3, topk_Metro=self.topk_Metro, topk_cloud=self.topk_cloud
            )

            if not allowE and not allowP and not allowC:
                task.fail()
                continue

            if self.use_ppo_for_decision:
                # State contains MEC-collab & Metro proximity features
                state = self.state_builder.build_state(task, P_idx)
                action_grp = self._choose_action3(state, allowE, allowP, allowC)

                if action_grp == 0 and allowE:
                    chosen_idx = allowE[0]; cnt_MEC_collab += 1
                elif action_grp == 1 and allowP:
                    chosen_idx = allowP[0]; cnt_Metro += 1
                else:
                    chosen_idx = (allowC or allowP or allowE)[0]
                    if chosen_idx in allowC:   cnt_cloud += 1
                    elif chosen_idx in allowP: cnt_Metro += 1
                    else:                      cnt_MEC_collab += 1

                sv = self.servers_list[chosen_idx]
                sv.allocate(task.id, task.cpu_demand, task.storage_demand, task.memory_demand,
                            current_time + sv.latency)
                # If Task.set_server expects (name, current_time), pass both.
                task.set_server(sv.name)
                assignments.append((task, sv))

                if self.training_mode:
                    r = self.reward_calculator.calculate_reward(task, chosen_idx)
                    mask = (1 if allowE else 0, 1 if allowP else 0, 1 if allowC else 0)
                    self.buffer.append((state, action_grp, r, mask))
                    sum_reward += r; n_reward += 1
            else:
                # Deterministic fallback: MEC-collab -> Metro -> Cloud
                chosen_idx = (allowE or allowP or allowC)[0]
                sv = self.servers_list[chosen_idx]
                sv.allocate(task.id, task.cpu_demand, task.storage_demand, task.memory_demand,
                            current_time + sv.latency)
                task.set_server(sv.name)
                assignments.append((task, sv))
                if chosen_idx in allowE:      cnt_MEC_collab += 1
                elif chosen_idx in allowP:    cnt_Metro += 1
                else:                          cnt_cloud += 1
                sum_reward += self.reward_calculator.calculate_reward(task, chosen_idx); n_reward += 1

        # ---- PPO update (batch) ----
        if self.training_mode and self.use_ppo_for_decision and len(self.buffer) >= self.buffer_threshold:
            self.last_actor_loss, self.last_critic_loss = self._train_ppo()
            if self.last_actor_loss is not None:
                self._actor_losses_hist.append(self.last_actor_loss)
            if self.last_critic_loss is not None:
                self._critic_losses_hist.append(self.last_critic_loss)

        # ---- Episode logging ----
        total_assigned = cnt_MEC_wp + cnt_MEC_collab + cnt_Metro + cnt_cloud
        mec_ratio = (cnt_MEC_wp + cnt_MEC_collab) / total_assigned if total_assigned else 0.0
        reg_ratio = cnt_Metro / total_assigned if total_assigned else 0.0
        cld_ratio = cnt_cloud / total_assigned if total_assigned else 0.0
        avg_reward = (sum_reward / max(1, n_reward))

        self.logger.log_episode(
            episode=self.episode_idx,
            updates=self.ppo_updates,
            buffer_len=len(self.buffer),
            avg_reward=avg_reward,
            action_ratios=(mec_ratio, reg_ratio, cld_ratio),
            actor_loss=self.last_actor_loss,
            critic_loss=self.last_critic_loss,
            training=self.training_mode
        )

        self._avg_rewards_hist.append(avg_reward)
        self._action_ratios_hist.append((mec_ratio, reg_ratio, cld_ratio))
        if (self.episode_idx + 1) % 10 == 0:
            self.logger.export_plots(
                avg_rewards=self._avg_rewards_hist,
                action_distribution=self._action_ratios_hist,
                actor_losses=self._actor_losses_hist,
                critic_losses=self._critic_losses_hist
            )

        self.episode_idx += 1
        return assignments
