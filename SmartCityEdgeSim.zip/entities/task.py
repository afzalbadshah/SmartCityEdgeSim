"""
RegionalEdgeSimPy — Educational Release

Author: Dr. Afzal Badshah
Department of Software Engineering, University of Sargodha
Website: https://afzalbadshah.com/index.php/afzal-badshah/
LinkedIn: https://www.linkedin.com/in/afzal-badshah-phd-305b03164/
Discussion Forum: resp.afzalbadshah.com

Notes:
- Functionality preserved; comments kept simple for student readability.
- Mobility fields are OPTIONAL and default to None/0.0 so legacy flows keep working.
"""

import uuid
from typing import Optional
from config.config import WORKLOAD


class Task:
    """
    A single workload item produced by an IoT device.
    Holds resource demands, size, priority, status, timing, and basic metrics.

    Mobility-aware fields (optional):
      - round:             simulation round index (int)
      - pos_x, pos_y:      device position at creation time (meters)
      - distance_to_bs:    distance to serving PEaaS/BS (meters)
      - signal_dbm:        simple signal strength proxy (dBm)
      - handover_delay_ms: extra delay if serving BS changed for this task (ms)
    """

    def __init__(self,
                 cpu_demand: float,
                 storage_demand: float,
                 memory_demand: float,
                 bandwidth: float,
                 latency: float,
                 priority: int = 1,
                 *,
                 # Optional mobility/context (safe defaults for legacy code)
                 round_index: Optional[int] = None,
                 pos_x: Optional[float] = None,
                 pos_y: Optional[float] = None,
                 distance_to_bs: Optional[float] = None,
                 signal_dbm: Optional[float] = None,
                 handover_delay_ms: float = 0.0):
        # Identity
        self.id = str(uuid.uuid4())

        # Resource demands (units are simulator-defined)
        self.cpu_demand = cpu_demand
        self.storage_demand = storage_demand
        self.memory_demand = memory_demand

        # Network characteristics at creation (used by schedulers/metrics)
        self.bandwidth = bandwidth
        self.latency = latency

        # Priority / flag
        self.priority = priority
        self.flag = priority  # kept for backward compatibility

        # Assignment fields
        self.server_assigned = None      # kept for compatibility with older code
        self.assigned_server = None      # current field used by set_server()

        # Data size (central knob from WORKLOAD)
        self.data_size_kb = WORKLOAD["data_per_device_kb"]

        # Execution timeline
        self.execution_start_time = None
        self.execution_end_time = None
        self.status = "created"

        # Basic per-task metrics (filled by simulator/scheduler)
        self.delay = 0.0
        self.cost = 0.0
        self.energy = 0.0

        # ---- Mobility / smart-city context (optional) ----
        self.round = round_index                  # used by reporter/scheduler logs
        self.pos_x = pos_x
        self.pos_y = pos_y
        self.distance_to_bs = distance_to_bs      # meters; used by mobility-aware propagation
        self.signal_dbm = signal_dbm              # optional for plotting/HO logic
        self.handover_delay_ms = float(handover_delay_ms or 0.0)

    # ------------------------------------------------------------------
    # Convenience setters (non-breaking)
    # ------------------------------------------------------------------

    def set_round(self, round_index: Optional[int]):
        """Attach/override round index (used by logs/plots)."""
        self.round = int(round_index) if round_index is not None else None

    def set_mobility(self,
                     x: Optional[float] = None,
                     y: Optional[float] = None,
                     distance_to_bs: Optional[float] = None,
                     signal_dbm: Optional[float] = None,
                     handover_ms: Optional[float] = None):
        """
        Attach/override mobility fields. Any None is ignored to avoid clobbering
        existing values if only one field is updated.
        """
        if x is not None: self.pos_x = float(x)
        if y is not None: self.pos_y = float(y)
        if distance_to_bs is not None: self.distance_to_bs = float(distance_to_bs)
        if signal_dbm is not None: self.signal_dbm = float(signal_dbm)
        if handover_ms is not None: self.handover_delay_ms = float(handover_ms)

    # ------------------------------------------------------------------
    # Lifecycle helpers
    # ------------------------------------------------------------------

    def set_server(self, server_name: str):
        """
        Mark this task as scheduled on a server.
        NOTE: We keep legacy `server_assigned` untouched on purpose to preserve
        is_assigned() behavior for older code paths that depend on it.
        """
        self.assigned_server = server_name
        self.status = "scheduled"

    def is_assigned(self) -> bool:
        """
        Returns True if legacy field `server_assigned` is set.
        NOTE: Preserved behavior; do not change to check `assigned_server`.
        """
        return self.server_assigned is not None

    def complete(self, start_time, end_time):
        """
        Mark the task as completed and record execution window.
        """
        self.execution_start_time = start_time
        self.execution_end_time = end_time
        self.status = "completed"

    def fail(self):
        """
        Mark the task as failed.
        """
        self.status = "failed"

    def execution_delay(self):
        """
        Duration between start and end times (0 if not both are set).
        """
        if self.execution_start_time is not None and self.execution_end_time is not None:
            return self.execution_end_time - self.execution_start_time
        return 0

    # ------------------------------------------------------------------
    # Serialization / logging
    # ------------------------------------------------------------------

    def to_dict(self):
        """
        Export task fields for logging/reporting.
        Mobility fields are included if present; blanks are fine when mobility is off.
        """
        return {
            "id": self.id,
            "round": self.round,
            "cpu_demand": self.cpu_demand,
            "storage_demand": self.storage_demand,
            "memory_demand": self.memory_demand,  # included for completeness
            "bandwidth": self.bandwidth,
            "latency": self.latency,
            "priority": self.priority,
            "data_size_kb": self.data_size_kb,
            "server": self.assigned_server,
            "status": self.status,
            "start_time": self.execution_start_time,
            "end_time": self.execution_end_time,
            "delay": self.delay,
            "cost": self.cost,
            "energy": self.energy,
            # Mobility extras
            "pos_x": self.pos_x,
            "pos_y": self.pos_y,
            "distance_to_bs": self.distance_to_bs,
            "signal_dbm": self.signal_dbm,
            "handover_ms": self.handover_delay_ms,
        }

    def __str__(self):
        """
        Human-readable summary (short ID).
        """
        short_id = self.id[:6]
        return (
            f"Task({short_id}) | CPU: {self.cpu_demand} | Storage: {self.storage_demand} | "
            f"Memory: {self.memory_demand} | Data: {self.data_size_kb}KB | "
            f"Priority: {self.priority} | Status: {self.status}"
        )
