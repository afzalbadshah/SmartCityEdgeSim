# live/live_map.py
import tkinter as tk
from tkinter import ttk
import math
from threading import Thread
from typing import Dict

try:
    from config.config import MOBILITY_CONFIG
except Exception:
    MOBILITY_CONFIG = {"area": {"xmin": 0.0, "xmax": 10000.0, "ymin": 0.0, "ymax": 10000.0}}

from .tiers import TIER_COLORS, tier_from_server_name, norm_tier_token
from .renderers import PAD, Assets, Layout, ServerRenderer, DeviceRenderer

BOTTOM_H = 160  # px for the bottom info bar


class LiveMap:
    """
    Two-phase UI:
      • SETUP: drag servers, positions persist live
      • RUN:   Start button disables dragging and starts simulation

    - No top HUD.
    - Draw order: devices → links → servers (servers always on top).
    - Footer is the single dashboard zone: counts ("legend") + utilization gauges.
    """
    def __init__(self, simulator, refresh_ms: int = 200):
        self.sim = simulator
        self.refresh_ms = refresh_ms
        self.mode = "SETUP"

        self.root = tk.Tk()
        self.root.title("SmartCityEdgeSimPy — Live Map")
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

        # --- Layout: top map + bottom dashboard ---
        self.top = tk.Frame(self.root, bd=0)
        self.bot = tk.Frame(self.root, bd=0, height=BOTTOM_H, bg="#ffffff")
        self.top.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        self.bot.pack(side=tk.BOTTOM, fill=tk.X)

        self.canvas = tk.Canvas(self.top, bg="#ffffff", highlightthickness=0)
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.canvas.bind("<Configure>", self._on_canvas_resize)

        # bounds
        area = MOBILITY_CONFIG.get("area", {})
        self.xmin = float(area.get("xmin", 0.0)); self.xmax = float(area.get("xmax", 10000.0))
        self.ymin = float(area.get("ymin", 0.0)); self.ymax = float(area.get("ymax", 10000.0))

        # renderers
        self.assets  = Assets(base_dir=self._root_dir())
        self.layout  = Layout(self.canvas, self.xmin, self.xmax, self.ymin, self.ymax)
        self.srvRen  = ServerRenderer(self.canvas, self.layout, self.assets)
        self.devRen  = DeviceRenderer(self.canvas, self.layout, self._device_color)
        self.srvRen.bind_handlers()
        self.srvRen.enable_drag(True)  # setup mode

        # footer dashboard
        self._build_footer()

        # link visuals
        self.link_items: Dict[tuple,int] = {}   # {(MEC_name, dest_name): line_id}
        self.dash_phase = 0

        self._closed = False
        self._sim_thread = None
        self._redraw_pending = False

        self.link_text_items: Dict[tuple, int] = {}  # (MEC,dest) -> text id
        self.link_text_bg:    Dict[tuple, int] = {}  # (MEC,dest) -> rect id


    # ---------- footer / dashboard ----------
    def _build_footer(self):
        # Left: controls
        controls = tk.Frame(self.bot, bg="#ffffff")
        controls.pack(side=tk.LEFT, padx=(12, 6), pady=8)

        self.start_btn = tk.Button(controls, text="▶ Start simulation", width=18, command=self._start_clicked)
        self.start_btn.grid(row=0, column=0, padx=(0, 8))

        # Default to "by TIER" to avoid confusion when validating attachment
        self.color_btn = tk.Button(controls, text="Color: by TIER (press C)", width=24, command=self._toggle_color_mode)
        self.color_btn.grid(row=0, column=1, padx=(0, 8))

        # vertical separator
        ttk.Separator(self.bot, orient="vertical").pack(side=tk.LEFT, fill=tk.Y, padx=6, pady=8)

        # Middle: COUNTS (legend) — horizontal row
        counts = tk.Frame(self.bot, bg="#ffffff")
        counts.pack(side=tk.LEFT, padx=10, pady=10)

        tk.Label(counts, text="Legend", font=("Segoe UI", 11, "bold"), bg="#ffffff").grid(row=0, column=0, columnspan=6, sticky="w", pady=(0, 4))

        def dot(parent, color):
            c = tk.Canvas(parent, width=14, height=14, bg="#ffffff", highlightthickness=0)
            c.create_oval(1, 1, 13, 13, fill=color, outline="")
            return c

        # MEC ● 0   |  Metro ● 0   |  Cloud ● 0
        self.dot_MEC = dot(counts, TIER_COLORS["MEC"]);  self.dot_MEC.grid(row=1, column=0, padx=(0,6))
        self.MEC_lbl = tk.Label(counts, text="MEC devices: 0", bg="#ffffff"); self.MEC_lbl.grid(row=1, column=1, padx=(0,12))
        self.dot_pea  = dot(counts, TIER_COLORS["Metro"]); self.dot_pea.grid(row=1, column=2, padx=(0,6))
        self.pea_lbl  = tk.Label(counts, text="Metro devices: 0", bg="#ffffff"); self.pea_lbl.grid(row=1, column=3, padx=(0,12))
        self.dot_cld  = dot(counts, TIER_COLORS["Cloud"]); self.dot_cld.grid(row=1, column=4, padx=(0,6))
        self.cld_lbl  = tk.Label(counts, text="Cloud devices: 0", bg="#ffffff"); self.cld_lbl.grid(row=1, column=5)

        # vertical separator
        ttk.Separator(self.bot, orient="vertical").pack(side=tk.LEFT, fill=tk.Y, padx=6, pady=8)

        # Right: UTILIZATION gauges
        stats = tk.Frame(self.bot, bg="#ffffff")
        stats.pack(side=tk.LEFT, padx=10, pady=8)

        tk.Label(stats, text="Stats (avg per tier)", font=("Segoe UI", 11, "bold"), bg="#ffffff").grid(row=0, column=0, columnspan=6, sticky="w", pady=(0, 6))
        self._gauges = {}  # tier -> {'cpu': (canvas,fill,width), 'mem': (...), 'cpu_lbl':Label, 'mem_lbl':Label}

        def mk_gauge(row, col_off, tier):
            color = TIER_COLORS[tier]
            # CPU
            tk.Label(stats, text=f"{tier} CPU", bg="#ffffff").grid(row=row, column=col_off+0, sticky="w", padx=(0,6))
            c1 = tk.Canvas(stats, width=160, height=12, bg="#f3f4f6", highlightthickness=0)
            f1 = c1.create_rectangle(0,0,0,12, fill=color, outline="")
            c1.grid(row=row, column=col_off+1, sticky="w")
            v1 = tk.Label(stats, text="0%", width=4, bg="#ffffff"); v1.grid(row=row, column=col_off+2, sticky="w", padx=(6,0))
            # MEM
            tk.Label(stats, text=f"{tier} MEM", bg="#ffffff").grid(row=row+1, column=col_off+0, sticky="w", padx=(0,6))
            c2 = tk.Canvas(stats, width=160, height=12, bg="#f3f4f6", highlightthickness=0)
            f2 = c2.create_rectangle(0,0,0,12, fill=color, outline="")
            c2.grid(row=row+1, column=col_off+1, sticky="w")
            v2 = tk.Label(stats, text="0%", width=4, bg="#ffffff"); v2.grid(row=row+1, column=col_off+2, sticky="w", padx=(6,0))
            self._gauges[tier] = {"cpu": (c1, f1, 160), "mem": (c2, f2, 160), "cpu_lbl": v1, "mem_lbl": v2}

        # arrange in two columns
        mk_gauge(1, 0, "MEC")
        mk_gauge(1, 3, "Metro")
        mk_gauge(3, 0, "Cloud")

        # keyboard toggle
        self.root.bind("c", self._toggle_color_mode)
        self.root.bind("C", self._toggle_color_mode)

    # ---------- controls ----------
    def _toggle_color_mode(self, _evt=None):
        txt = self.color_btn["text"]
        if "SERVER" in txt:
            self.color_btn.config(text="Color: by TIER (press C)")
        else:
            self.color_btn.config(text="Color: by SERVER (press C)")

    def _start_clicked(self):
        if self.mode == "RUN": return
        self.srvRen.enable_drag(False)    # lock layout
        self.start_btn.config(state="disabled")
        self.mode = "RUN"
        self._sim_thread = Thread(target=self.sim.run, daemon=True, name="SimulatorThread")
        self._sim_thread.start()

    # ---------- coloring ----------
    def _device_tier(self, ent) -> str:
        for attr in ("last_offload_tier", "offload_tier", "processing_tier"):
            v = getattr(ent, attr, None)
            if isinstance(v, str): return norm_tier_token(v)
        asrv = getattr(ent, "attached_server", None)
        if asrv is None: return "Unknown"
        t_attr = getattr(asrv, "tier", None)
        return norm_tier_token(t_attr) if isinstance(t_attr, str) \
               else tier_from_server_name(getattr(asrv, "name",""))

    def _device_color(self, ent) -> str:
        by_server = "SERVER" in self.color_btn["text"]
        if by_server:
            asrv = getattr(ent, "attached_server", None)
            if asrv is not None:
                k = f"{getattr(asrv,'name','srv')}#{getattr(asrv,'id',None) or id(asrv)}"
                return self.srvRen.server_colors.get(k, "#111827")
            return "#111827"
        return TIER_COLORS.get(self._device_tier(ent), "#6b7280")

    # ---------- resize & tick ----------
    def _on_canvas_resize(self, _evt):
        if not self._redraw_pending:
            self._redraw_pending = True
            self.root.after(0, self._redraw_now)

    def _redraw_now(self):
        self._redraw_pending = False
        self._draw_content()

    def _draw_content(self):
        svs = getattr(self.sim, "servers", [])

        # 1) devices first (lowest)
        m = getattr(self.sim, "mobility", None)
        self.devRen.draw(getattr(m, "entities", [])) if m else None

        # 2) animated MEC->(Metro/Cloud) links
        self._draw_links()

        # 3) servers last (always on top)
        self.srvRen.assign_palette(svs)
        self.srvRen.draw(svs)
        self.canvas.tag_raise("srv")

        # footer updates
        self._update_counts()
        self._update_gauges()

    def _draw_links(self):
        """
        Draw MEC/Metro/Cloud links.
        UI-only change: any server whose name starts with "Cloud" is drawn
        at the top-right corner of the canvas (inside PAD), WITHOUT changing
        the simulation coordinates used elsewhere.
        """
        alive = set()

        # ---- Map server name -> (cx, cy) in canvas space ----
        # (Cloud is overridden to a fixed on-screen anchor; others unchanged.)
        name_to_pos: Dict[str, tuple] = {}
        w = max(1, self.canvas.winfo_width())
        cloud_anchor = (w - PAD, PAD)  # top-right corner inside padding

        for s in getattr(self.sim, "servers", []):
            x = getattr(s, "x", None)
            y = getattr(s, "y", None)
            if x is None or y is None:
                continue

            name = str(getattr(s, "name", "") or "")
            if name.startswith("Cloud"):
                cx, cy = cloud_anchor
            else:
                cx = self.layout.sx(float(x))
                cy = self.layout.sy(float(y))

            name_to_pos[name] = (cx, cy)

        # ---- Draw each published link ----
        for link in getattr(self.sim, "gui_links", []):
            edge = str(link.get("MEC", "") or "")
            dest = str(link.get("to", link.get("Metro", "")) or "")
            tier = str(link.get("tier", "Metro") or "Metro")
            color = TIER_COLORS.get(tier, TIER_COLORS.get("Unknown", "#6b7280"))

            if edge not in name_to_pos or dest not in name_to_pos:
                continue

            ex, ey = name_to_pos[edge]
            dx, dy = name_to_pos[dest]

            key = (edge, dest)
            width = max(1, int(math.log2(max(1, int(link.get("count", 1))))) + 1)

            if key not in self.link_items:
                self.link_items[key] = self.canvas.create_line(
                    ex, ey, dx, dy, fill=color, width=width, arrow=tk.LAST
                )
            else:
                self.canvas.coords(self.link_items[key], ex, ey, dx, dy)
                self.canvas.itemconfig(self.link_items[key], fill=color, width=width)
            alive.add(key)

            # ----- Optional delay label if avg_delay_ms is provided -----
            avg_ms = link.get("avg_delay_ms", None)
            if avg_ms is None:
                if key in self.link_text_items:
                    self.canvas.delete(self.link_text_items[key])
                    self.link_text_items.pop(key, None)
                if key in self.link_text_bg:
                    self.canvas.delete(self.link_text_bg[key])
                    self.link_text_bg.pop(key, None)
                continue

            # Place small label at the midpoint, nudged off the line
            mx = (ex + dx) / 2.0
            my = (ey + dy) / 2.0
            vx, vy = (dx - ex), (dy - ey)
            L = math.hypot(vx, vy) or 1.0
            nx, ny = -vy / L, vx / L
            mx += nx * 10.0
            my += ny * 10.0

            label = f"{avg_ms:.0f} ms" if avg_ms < 1000 else f"{avg_ms/1000:.1f} s"

            if key not in self.link_text_items:
                txt = self.canvas.create_text(mx, my, text=label, font=("Segoe UI", 9), fill=color)
                x1, y1, x2, y2 = self.canvas.bbox(txt)
                bg = self.canvas.create_rectangle(x1 - 4, y1 - 2, x2 + 4, y2 + 2,
                                                fill="#ffffff", outline="#e5e7eb")
                self.canvas.tag_lower(bg, txt)
                self.link_text_items[key] = txt
                self.link_text_bg[key] = bg
            else:
                txt = self.link_text_items[key]
                self.canvas.itemconfig(txt, text=label, fill=color)
                self.canvas.coords(txt, mx, my)
                x1, y1, x2, y2 = self.canvas.bbox(txt)
                self.canvas.coords(self.link_text_bg[key], x1 - 4, y1 - 2, x2 + 4, y2 + 2)
                self.canvas.tag_lower(self.link_text_bg[key], txt)

        # ---- Prune stale lines/labels ----
        for key, item in list(self.link_items.items()):
            if key not in alive:
                self.canvas.delete(item)
                self.link_items.pop(key, None)
                if key in self.link_text_items:
                    self.canvas.delete(self.link_text_items[key])
                    self.link_text_items.pop(key, None)
                if key in self.link_text_bg:
                    self.canvas.delete(self.link_text_bg[key])
                    self.link_text_bg.pop(key, None)


    # ---------- footer data updates ----------
    def _update_counts(self):
        """
        Prefer simulator-published per-tier device counts for this round
        (gui_tier_counts). Fallback to attachment-based counting if not present.
        """
        counts = getattr(self.sim, "gui_tier_counts", None)
        if isinstance(counts, dict) and {"MEC", "Metro", "Cloud"} <= set(counts.keys()):
            self.MEC_lbl.config(text=f"MEC devices: {int(counts.get('MEC',0))}")
            self.pea_lbl.config(text=f"Metro devices: {int(counts.get('Metro',0))}")
            self.cld_lbl.config(text=f"Cloud devices: {int(counts.get('Cloud',0))}")
            return

        # Fallback: attachment-based
        tcounts: Dict[str,int] = {"MEC":0,"Metro":0,"Cloud":0}
        m = getattr(self.sim, "mobility", None)
        if not m:
            self.MEC_lbl.config(text="MEC devices: 0")
            self.pea_lbl.config(text="Metro devices: 0")
            self.cld_lbl.config(text="Cloud devices: 0")
            return
        for e in getattr(m, "entities", []):
            tier = self._device_tier(e)
            tcounts[tier] = tcounts.get(tier, 0) + 1
        self.MEC_lbl.config(text=f"MEC devices: {tcounts.get('MEC',0)}")
        self.pea_lbl.config(text=f"Metro devices: {tcounts.get('Metro',0)}")
        self.cld_lbl.config(text=f"Cloud devices: {tcounts.get('Cloud',0)}")

    def _update_gauges(self):
        utils = self._compute_tier_utils()  # {'MEC':(cpu%,mem%), ...}
        for tier, (cpu, mem) in utils.items():
            g = self._gauges.get(tier)
            if not g: continue
            c1, f1, w1 = g["cpu"]; c1.coords(f1, 0, 0, w1 * max(0.0, min(cpu, 100.0)) / 100.0, 12)
            g["cpu_lbl"].config(text=f"{int(round(cpu))}%")
            c2, f2, w2 = g["mem"]; c2.coords(f2, 0, 0, w2 * max(0.0, min(mem, 100.0)) / 100.0, 12)
            g["mem_lbl"].config(text=f"{int(round(mem))}%")

    def _compute_tier_utils(self):
        totals = {
            "MEC":  {"cpu_used":0.0,"cpu_tot":0.0,"mem_used":0.0,"mem_tot":0.0},
            "Metro": {"cpu_used":0.0,"cpu_tot":0.0,"mem_used":0.0,"mem_tot":0.0},
            "Cloud": {"cpu_used":0.0,"cpu_tot":0.0,"mem_used":0.0,"mem_tot":0.0},
        }
        for s in getattr(self.sim, "servers", []):
            name = str(getattr(s, "name", ""))
            if   name.startswith("MEC"):  tier = "MEC"
            elif name.startswith("Metro"): tier = "Metro"
            elif name.startswith("Cloud"): tier = "Cloud"
            else: continue
            cpu_cap = float(getattr(s, "cpu_capacity", 0.0) or 0.0)
            mem_cap = float(getattr(s, "memory_capacity", 0.0) or 0.0)
            cpu_used = max(0.0, cpu_cap - float(getattr(s, "available_cpu", 0.0) or 0.0))
            mem_used = max(0.0, mem_cap - float(getattr(s, "available_memory", 0.0) or 0.0))
            totals[tier]["cpu_used"] += cpu_used
            totals[tier]["cpu_tot"]  += cpu_cap
            totals[tier]["mem_used"] += mem_used
            totals[tier]["mem_tot"]  += mem_cap

        out = {}
        for tier, t in totals.items():
            cpu = (t["cpu_used"]/t["cpu_tot"]*100.0) if t["cpu_tot"]>0 else 0.0
            mem = (t["mem_used"]/t["mem_tot"]*100.0) if t["mem_tot"]>0 else 0.0
            out[tier] = (cpu, mem)
        return out

    # ---------- utils ----------
    def _root_dir(self) -> str:
        import os
        return os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

    def _on_close(self):
        self._closed = True
        self.root.destroy()

    def _tick(self):
        if self._closed: return
        try:
            self._draw_content()
        except Exception as e:
            print("[LiveMap] frame error:", e)
        self.root.after(self.refresh_ms, self._tick)

    def _cloud_draw_anchor(self):
        """Canvas coords for Cloud endpoint (top-right corner, inside PAD)."""
        w = max(1, self.canvas.winfo_width())
        return (w - PAD, PAD)


    def start(self):
        self._tick()
        self.root.mainloop()
