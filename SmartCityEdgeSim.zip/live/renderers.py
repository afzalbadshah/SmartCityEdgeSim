# live/renderers.py
import os
import math
import tkinter as tk
from typing import Dict, List, Tuple, Optional

from .tiers import TIER_COLORS, SERVER_PALETTE, tier_from_server_obj

PAD        = 24
ICON_SIZE  = 22
DEVICE_R   = 3
GRID_SNAP  = 3  # px; small bucketing to avoid perfect overlaps


def _srv_key(srv) -> str:
    return f"{getattr(srv, 'name', 'srv')}#{getattr(srv, 'id', None) or id(srv)}"


class Assets:
    def __init__(self, base_dir: str):
        self.assets_dir = os.path.join(base_dir, "assets")
        if not os.path.isdir(self.assets_dir):
            self.assets_dir = os.path.join(os.path.dirname(__file__), "assets")
        self.MEC   = self._load("MEC")
        self.Metro  = self._load("metro") 
        self.cloud  = self._load("cloud")
        self.by_tier = {"MEC": self.MEC, "Metro": self.Metro, "Cloud": self.cloud}

    def _load(self, name: str):
        p = os.path.join(self.assets_dir, f"{name}.png")
        if not os.path.isfile(p):
            return None
        try:
            img = tk.PhotoImage(file=p)
            fx = max(1, img.width()  // ICON_SIZE)
            fy = max(1, img.height() // ICON_SIZE)
            return img.subsample(fx, fy) if (fx > 1 or fy > 1) else img
        except Exception:
            return None


class Layout:
    """Transforms between simulation coords and canvas pixels, live-sized."""
    def __init__(self, canvas: tk.Canvas, xmin: float, xmax: float, ymin: float, ymax: float):
        self.cv   = canvas
        self.xmin = xmin; self.xmax = xmax
        self.ymin = ymin; self.ymax = ymax

    def sx(self, x: float) -> float:
        w = max(1, self.cv.winfo_width())
        if self.xmax == self.xmin: return PAD
        return PAD + (x - self.xmin) * (w - 2*PAD) / (self.xmax - self.xmin)

    def sy(self, y: float) -> float:
        h = max(1, self.cv.winfo_height())
        if self.ymax == self.ymin: return PAD
        return h - PAD - (y - self.ymin) * (h - 2*PAD) / (self.ymax - self.ymin)

    def inv_sx(self, cx: float) -> float:
        w = max(1, self.cv.winfo_width())
        return self.xmin + (cx - PAD) * (self.xmax - self.xmin) / max(1.0, (w - 2*PAD))

    def inv_sy(self, cy: float) -> float:
        h = max(1, self.cv.winfo_height())
        return self.ymin + (h - PAD - cy) * (self.ymax - self.ymin) / max(1.0, (h - 2*PAD))

    def clamp_canvas(self, cx: float, cy: float) -> Tuple[float, float]:
        w, h = self.cv.winfo_width(), self.cv.winfo_height()
        return (min(max(PAD, cx), w - PAD), min(max(PAD, cy), h - PAD))


class ServerRenderer:
    """Draw servers, allow drag in Setup, resolve near-overlaps, persist positions."""
    def __init__(self, canvas: tk.Canvas, layout: Layout, assets: Assets):
        self.cv = canvas
        self.ly = layout
        self.assets = assets

        self.server_colors: Dict[str, str] = {}
        self.ring_items:   Dict[str, int]  = {}
        self.icon_items:   Dict[str, int]  = {}
        self.label_items:  Dict[str, int]  = {}
        self.label_bg:     Dict[str, int]  = {}

        self.drag_enabled = False
        self._drag_key: Optional[str] = None
        self._drag_dx = 0.0
        self._drag_dy = 0.0

        self._servers_ref: List[object] = []  # updated on each draw()

    def assign_palette(self, servers: List[object]):
        self.server_colors.clear
        for i, s in enumerate(servers):
            self.server_colors[_srv_key(s)] = SERVER_PALETTE[i % len(SERVER_PALETTE)]

    def _compute_positions(self, servers: List[object]) -> Dict[str, Tuple[float, float]]:
        """Return {key: (cx,cy)} with light anti-overlap bucketing."""
        pos: Dict[str, Tuple[float,float]] = {}
        buckets: Dict[Tuple[int,int], List[Tuple[str,float,float]]] = {}
        for s in servers:
            x, y = getattr(s, "x", None), getattr(s, "y", None)
            if x is None or y is None: 
                continue
            cx, cy = self.ly.sx(float(x)), self.ly.sy(float(y))
            ix, iy = int(round(cx/GRID_SNAP))*GRID_SNAP, int(round(cy/GRID_SNAP))*GRID_SNAP
            buckets.setdefault((ix,iy), []).append((_srv_key(s), cx, cy))



        for (ix,iy), items in buckets.items():
            if len(items) == 1:
                k,cx,cy = items[0]; pos[k] = (cx,cy)
            else:
                R = 14.0
                for j,(k,cx,cy) in enumerate(items):
                    ang = 2*math.pi*j/len(items)
                    pos[k] = (ix + R*math.cos(ang), iy + R*math.sin(ang))
        return pos

    def _tag(self, key: str) -> str:
        return f"srv:{key}"

    def enable_drag(self, enable: bool):
        self.drag_enabled = bool(enable)

    # ----- mouse handlers -----
    def bind_handlers(self):
        self.cv.tag_bind("srv", "<ButtonPress-1>",  self._on_down)
        self.cv.tag_bind("srv", "<B1-Motion>",      self._on_move)
        self.cv.tag_bind("srv", "<ButtonRelease-1>",self._on_up)

    def _find_server_by_key(self, key: str):
        for s in self._servers_ref:
            if _srv_key(s) == key:
                return s
        return None

    def _on_down(self, evt):
        if not self.drag_enabled: return
        items = self.cv.find_withtag("current")
        if not items: return
        for key, item in self.icon_items.items():
            if item == items[0]:
                self._drag_key = key
                x0,y0 = self.cv.coords(item)
                self._drag_dx, self._drag_dy = x0 - evt.x, y0 - evt.y
                return

    def _on_move(self, evt):
        if not self.drag_enabled or not self._drag_key: return
        cx, cy = self.ly.clamp_canvas(evt.x + self._drag_dx, evt.y + self._drag_dy)
        self._move_drawn(self._drag_key, cx, cy)
        # Persist back into server object (no reset button needed)
        srv = self._find_server_by_key(self._drag_key)
        if srv is not None:
            setattr(srv, "x", float(self.ly.inv_sx(cx)))
            setattr(srv, "y", float(self.ly.inv_sy(cy)))

    def _on_up(self, _evt):
        self._drag_key = None

    def _move_drawn(self, key: str, cx: float, cy: float):
        if key in self.icon_items:
            iid = self.icon_items[key]
            if self.cv.type(iid) == "image":
                self.cv.coords(iid, cx, cy)
            else:
                size = 12
                self.cv.coords(iid, cx - size, cy - size, cx + size, cy + size)
        if key in self.ring_items:
            r = 16
            self.cv.coords(self.ring_items[key], cx - r, cy - r, cx + r, cy + r)
        if key in self.label_items and key in self.label_bg:
            txt = self.label_items[key]
            self.cv.coords(txt, cx, cy - 18)
            x1,y1,x2,y2 = self.cv.bbox(txt)
            self.cv.coords(self.label_bg[key], x1 - 4, y1 - 2, x2 + 4, y2 + 2)
            self.cv.tag_raise(txt, self.label_bg[key])

    def draw(self, servers: List[object], color_mode: str = "tier"):
        self._servers_ref = servers
        if not self.server_colors:
            self.assign_palette(servers)

        pos = self._compute_positions(servers)

        # draw rings + icons + labels
        for s in servers:
            key = _srv_key(s)
            cx, cy = pos.get(
                key,
                (self.ly.sx(getattr(s, "x", 0.0)), self.ly.sy(getattr(s, "y", 0.0)))
            )
            tier = tier_from_server_obj(s)
            color = (
                TIER_COLORS.get(tier, "#888888")
                if color_mode == "tier"
                else self.server_colors.get(key, "#888888")
            )

            # ---- draw-only override for Cloud: place icon top-right inside padding ----
            if tier == "Cloud":
                w = max(1, self.cv.winfo_width())
                draw_cx, draw_cy = (w - PAD, PAD)
            else:
                draw_cx, draw_cy = (cx, cy)

            # ring
            r = 10
            if key not in self.ring_items:
                self.ring_items[key] = self.cv.create_oval(
                    draw_cx - r, draw_cy - r, draw_cx + r, draw_cy + r,
                    outline=color, width=2
                )
            else:
                self.cv.coords(self.ring_items[key], draw_cx - r, draw_cy - r, draw_cx + r, draw_cy + r)
                self.cv.itemconfig(self.ring_items[key], outline=color)

            # icon
            img = self.assets.by_tier.get(tier)
            if key not in self.icon_items:
                if img is not None:
                    self.icon_items[key] = self.cv.create_image(draw_cx, draw_cy, image=img)
                else:
                    self.icon_items[key] = self.cv.create_rectangle(
                        draw_cx - 6, draw_cy - 6, draw_cx + 6, draw_cy + 6,
                        fill=color, outline=""
                    )
            else:
                self.cv.coords(self.icon_items[key], draw_cx, draw_cy)

            # label
            label = getattr(s, "name", "srv")
            if key not in self.label_items:
                t = self.cv.create_text(draw_cx, draw_cy + 16, text=label, font=("Segoe UI", 9))
                x1, y1, x2, y2 = self.cv.bbox(t)
                bg = self.cv.create_rectangle(x1 - 4, y1 - 2, x2 + 4, y2 + 2, fill="#ffffff", outline="#e5e7eb")
                self.cv.tag_lower(bg, t)
                self.label_items[key] = t
                self.label_bg[key] = bg
            else:
                t = self.label_items[key]
                self.cv.itemconfig(t, text=label)
                self.cv.coords(t, draw_cx, draw_cy + 16)
                x1, y1, x2, y2 = self.cv.bbox(t)
                self.cv.coords(self.label_bg[key], x1 - 4, y1 - 2, x2 + 4, y2 + 2)
                self.cv.tag_lower(self.label_bg[key], t)



class DeviceRenderer:
    """Draw devices as tiny dots; keep them on a separate 'dev' tag."""
    def __init__(self, canvas: tk.Canvas, layout: Layout, color_fn):
        self.cv = canvas
        self.ly = layout
        self.color_fn = color_fn
        self.items: Dict[int,int] = {}  # entity_id -> canvas_oval_id

    @staticmethod
    def _extract_xy(ent) -> Tuple[Optional[float], Optional[float]]:
        pos = getattr(ent, "position", None)
        if isinstance(pos, (list, tuple)) and len(pos) >= 2:
            return float(pos[0]), float(pos[1])
        if isinstance(pos, dict):
            if "x" in pos and "y" in pos: return float(pos["x"]), float(pos["y"])
            if "X" in pos and "Y" in pos: return float(pos["X"]), float(pos["Y"])
        if hasattr(ent, "x") and hasattr(ent, "y"):
            return float(getattr(ent, "x")), float(getattr(ent, "y"))
        return None, None

    def _compute_positions(self, entities) -> Dict[int, Tuple[float,float]]:
        """Return {entity_id: (cx,cy)} with tiny anti-overlap bucketing."""
        pos: Dict[int, Tuple[float,float]] = {}
        buckets: Dict[Tuple[int,int], List[Tuple[int,float,float]]] = {}
        for e in entities or []:
            ent_id = getattr(e, "id", None)
            x, y = self._extract_xy(e)
            if ent_id is None or x is None or y is None:
                continue
            cx, cy = self.ly.sx(float(x)), self.ly.sy(float(y))
            ix = int(round(cx/GRID_SNAP))*GRID_SNAP
            iy = int(round(cy/GRID_SNAP))*GRID_SNAP
            buckets.setdefault((ix,iy), []).append((ent_id, cx, cy))
        for (ix,iy), items in buckets.items():
            if len(items) == 1:
                eid,cx,cy = items[0]; pos[eid]=(cx,cy)
            else:
                R = 6.0
                n = len(items)
                for j,(eid,cx,cy) in enumerate(items):
                    ang = 2*math.pi*j/n
                    pos[eid] = (ix + R*math.cos(ang), iy + R*math.sin(ang))
        return pos

    def draw(self, entities: List[object]):
        if not entities:
            return
        positions = self._compute_positions(entities)
        r = DEVICE_R
        for e in entities:
            ent_id = getattr(e, "id", None)
            if ent_id is None or ent_id not in positions:
                continue
            cx, cy = positions[ent_id]
            fill = self.color_fn(e)
            if ent_id not in self.items:
                self.items[ent_id] = self.cv.create_oval(cx - r, cy - r, cx + r, cy + r,
                                                         fill=fill, outline="", tags=("dev",))
            else:
                iid = self.items[ent_id]
                self.cv.coords(iid, cx - r, cy - r, cx + r, cy + r)
                self.cv.itemconfig(iid, fill=fill)



    def _cloud_draw_anchor(self):
        """Canvas coords for Cloud icon (top-right corner, inside PAD)."""
        w = max(1, self.cv.winfo_width())
        return (w - PAD, PAD)
