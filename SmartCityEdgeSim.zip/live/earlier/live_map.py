# live/live_map.py
import tkinter as tk
import math
from threading import Thread
from typing import Dict

try:
    from config.config import MOBILITY_CONFIG
except Exception:
    MOBILITY_CONFIG = {"area": {"xmin": 0.0, "xmax": 10000.0, "ymin": 0.0, "ymax": 10000.0}}

from .tiers import TIER_COLORS, tier_from_server_name, norm_tier_token
from .renderers import PAD, Assets, Layout, ServerRenderer, DeviceRenderer

BOTTOM_H = 120  # px for the bottom info bar

class LiveMap:
    """
    Two-phase UI:
      • SETUP: drag servers to desired positions (drag persists immediately)
      • RUN:   Start button disables dragging and starts the simulation
    Legend & controls live in a bottom bar; map scales with window size.
    """
    def __init__(self, simulator, refresh_ms: int = 200):
        self.sim = simulator
        self.refresh_ms = refresh_ms
        self.mode = "SETUP"

        self.root = tk.Tk()
        self.root.title("RegionalEdgeSimPy — Live Map")
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

        # --- Layout: top map + bottom info bar ---
        self.top = tk.Frame(self.root, bd=0)
        self.bot = tk.Frame(self.root, bd=0, height=BOTTOM_H, bg="#ffffff")
        self.top.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        self.bot.pack(side=tk.BOTTOM, fill=tk.X)

        self.canvas = tk.Canvas(self.top, bg="#ffffff", highlightthickness=0)
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.canvas.bind("<Configure>", self._on_canvas_resize)

        # bounds
        area = MOBILITY_CONFIG.get("area", {})
        self.xmin = float(area.get("xmin", 0.0)); self.xmax = float(area.get("xmax", 10000.0))
        self.ymin = float(area.get("ymin", 0.0)); self.ymax = float(area.get("ymax", 10000.0))

        # renderers
        self.assets  = Assets(base_dir=self._root_dir())
        self.layout  = Layout(self.canvas, self.xmin, self.xmax, self.ymin, self.ymax)
        self.srvRen  = ServerRenderer(self.canvas, self.layout, self.assets)
        self.devRen  = DeviceRenderer(self.canvas, self.layout, self._device_color)
        self.srvRen.bind_handlers()
        self.srvRen.enable_drag(True)  # setup mode

        # HUD
        self.hud = self.canvas.create_text(PAD, PAD, anchor="nw",
                                           font=("Segoe UI", 11, "bold"),
                                           fill="#111827", text="Setup: drag servers, then press Start")

        # bottom bar
        self._build_bottom_bar()

        # link visuals
        self.link_items = {}   # {(edge_name, peaas_name): line_id}
        self.dash_phase = 0

        self._closed = False
        self._sim_thread = None
        self._redraw_pending = False

    # ---------- bottom bar ----------
    def _build_bottom_bar(self):
        left = tk.Frame(self.bot, bg="#ffffff")
        left.pack(side=tk.LEFT, padx=12, pady=8)

        self.start_btn = tk.Button(left, text="▶ Start simulation", width=18, command=self._start_clicked)
        self.start_btn.grid(row=0, column=0, padx=4)

        # Default to "by TIER" to avoid confusion when validating attachment
        self.color_btn = tk.Button(left, text="Color: by TIER (press C)", width=24, command=self._toggle_color_mode)
        self.color_btn.grid(row=0, column=1, padx=8)

        right = tk.Frame(self.bot, bg="#ffffff")
        right.pack(side=tk.RIGHT, padx=16, pady=8)
        self._mk_legend(right)

        self.root.bind("c", self._toggle_color_mode)
        self.root.bind("C", self._toggle_color_mode)

    def _mk_legend(self, parent):
        def _mk_icon(color_hex):
            f = tk.Canvas(parent, width=14, height=14, highlightthickness=0, bg="#ffffff")
            f.create_oval(1,1,13,13, fill=color_hex, outline="")
            return f
        title = tk.Label(parent, text="Legend", font=("Segoe UI", 11, "bold"), bg="#ffffff")
        title.grid(row=0, column=0, sticky="w", columnspan=2, pady=(0,6))
        self._edge_icon = _mk_icon(TIER_COLORS["Edge"]);  self._edge_icon.grid(row=1, column=0, padx=(0,8))
        self.edge_lbl   = tk.Label(parent, text="Edge devices: 0", bg="#ffffff");   self.edge_lbl.grid(row=1, column=1, sticky="w")
        self._pea_icon  = _mk_icon(TIER_COLORS["PEaaS"]); self._pea_icon.grid(row=2, column=0, padx=(0,8))
        self.pea_lbl    = tk.Label(parent, text="PEaaS devices: 0", bg="#ffffff");  self.pea_lbl.grid(row=2, column=1, sticky="w")
        self._cld_icon  = _mk_icon(TIER_COLORS["Cloud"]); self._cld_icon.grid(row=3, column=0, padx=(0,8))
        self.cld_lbl    = tk.Label(parent, text="Cloud devices: 0", bg="#ffffff");  self.cld_lbl.grid(row=3, column=1, sticky="w")

    # ---------- controls ----------
    def _toggle_color_mode(self, _evt=None):
        txt = self.color_btn["text"]
        if "SERVER" in txt:
            self.color_btn.config(text="Color: by TIER (press C)")
        else:
            self.color_btn.config(text="Color: by SERVER (press C)")

    def _start_clicked(self):
        if self.mode == "RUN": return
        self.srvRen.enable_drag(False)    # lock layout
        self.start_btn.config(state="disabled")
        self.mode = "RUN"
        self.canvas.itemconfig(self.hud, text="Running…")
        self._sim_thread = Thread(target=self.sim.run, daemon=True, name="SimulatorThread")
        self._sim_thread.start()

    # ---------- coloring ----------
    def _device_tier(self, ent) -> str:
        for attr in ("last_offload_tier", "offload_tier", "processing_tier"):
            v = getattr(ent, attr, None)
            if isinstance(v, str): return norm_tier_token(v)
        asrv = getattr(ent, "attached_server", None)
        if asrv is None: return "Unknown"
        t_attr = getattr(asrv, "tier", None)
        return norm_tier_token(t_attr) if isinstance(t_attr, str) \
               else tier_from_server_name(getattr(asrv, "name",""))

    def _device_color(self, ent) -> str:
        by_server = "SERVER" in self.color_btn["text"]
        if by_server:
            asrv = getattr(ent, "attached_server", None)
            if asrv is not None:
                k = f"{getattr(asrv,'name','srv')}#{getattr(asrv,'id',None) or id(asrv)}"
                return self.srvRen.server_colors.get(k, "#111827")
            return "#111827"
        return TIER_COLORS.get(self._device_tier(ent), "#6b7280")

    # ---------- resize & tick ----------
    def _on_canvas_resize(self, _evt):
        if not self._redraw_pending:
            self._redraw_pending = True
            self.root.after(0, self._redraw_now)

    def _redraw_now(self):
        self._redraw_pending = False
        self._draw_content()

    def _draw_content(self):
        svs = getattr(self.sim, "servers", [])
        self.srvRen.assign_palette(svs)
        self.srvRen.draw(svs)

        m = getattr(self.sim, "mobility", None)
        self.devRen.draw(getattr(m, "entities", [])) if m else None

        # NEW: draw animated Edge->PEaaS links
        self._draw_links()

        # HUD / counts
        ho_count = getattr(self.sim.mobility, "ho_count", 0) if hasattr(self.sim, "mobility") else 0
        ho_delay = getattr(self.sim.mobility, "ho_delay", 0) if hasattr(self.sim, "mobility") else 0
        ct       = getattr(self.sim, "current_time", 0)
        prefix   = "Setup: drag servers, then press Start" if self.mode=="SETUP" else "Time"
        text     = f"{prefix}: {ct}   |   Handovers: {ho_count}   |   Total HO Delay (ms): {ho_delay}"
        self.canvas.itemconfig(self.hud, text=text)

        self._update_counts()

    def _draw_links(self):
        """
        Draw/update animated dashed lines for Edge->(PEaaS|Cloud) pairs published
        by the simulator in self.sim.gui_links. Each entry:
        {'edge': 'Edge_1', 'to': 'PEaaS_1'|'Cloud_1', 'tier': 'PEaaS'|'Cloud', 'count': N}
        Also supports the legacy shape {'edge':..., 'peaas':..., 'count':...}.
        """
        links = getattr(self.sim, "gui_links", []) or []
        if not links:
            for _, item in list(self.link_items.items()):
                self.canvas.delete(item)
            self.link_items.clear()
            return

        # Map server name -> (cx,cy)
        name_to_pos: Dict[str, tuple] = {}
        for s in getattr(self.sim, "servers", []):
            x = getattr(s, "x", None); y = getattr(s, "y", None)
            if x is None or y is None: 
                continue
            name = str(getattr(s, "name", ""))
            name_to_pos[name] = (self.layout.sx(float(x)), self.layout.sy(float(y)))

        # animate dash movement
        self.dash_phase = (self.dash_phase + 2) % 1000

        alive = set()
        for link in links:
            edge = str(link.get("edge", ""))
            # new generic 'to' or legacy 'peaas'
            dest = str(link.get("to", link.get("peaas", "")))
            tier = str(link.get("tier", "PEaaS"))  # default to PEaaS if not provided
            cnt  = int(link.get("count", 1))
            if edge not in name_to_pos or dest not in name_to_pos:
                continue

            ex, ey = name_to_pos[edge]
            dx, dy = name_to_pos[dest]
            key = (edge, dest)

            # width scales softly with count
            import math as _math
            width = max(1, min(6, 1 + int(_math.log2(max(1, cnt)))))

            # color by destination tier (PEaaS orange, Cloud green)
            color = TIER_COLORS.get(tier, TIER_COLORS["PEaaS"])

            if key not in self.link_items:
                item = self.canvas.create_line(
                    ex, ey, dx, dy,
                    fill=color,
                    width=width,
                    dash=(10, 6),
                    dashoffset=self.dash_phase,
                    arrow="last",
                    capstyle=tk.ROUND,
                    joinstyle=tk.ROUND,
                )
                self.link_items[key] = item
            else:
                item = self.link_items[key]
                self.canvas.coords(item, ex, ey, dx, dy)
                self.canvas.itemconfig(item, width=width, fill=color, dashoffset=self.dash_phase)
            alive.add(key)

        # prune any stale links
        for key, item in list(self.link_items.items()):
            if key not in alive:
                self.canvas.delete(item)
                del self.link_items[key]


    def _update_counts(self):
        """
        Prefer simulator-published per-tier device counts for this round
        (gui_tier_counts). Fallback to attachment-based counting if not present.
        """
        counts = getattr(self.sim, "gui_tier_counts", None)
        if isinstance(counts, dict) and {"Edge", "PEaaS", "Cloud"} <= set(counts.keys()):
            self.edge_lbl.config(text=f"Edge devices: {int(counts.get('Edge',0))}")
            self.pea_lbl.config(text=f"PEaaS devices: {int(counts.get('PEaaS',0))}")
            self.cld_lbl.config(text=f"Cloud devices: {int(counts.get('Cloud',0))}")
            return

        # Fallback: attachment-based (all will look Edge if you use Edge-only WPs)
        tcounts: Dict[str,int] = {"Edge":0,"PEaaS":0,"Cloud":0}
        m = getattr(self.sim, "mobility", None)
        if not m:
            self.edge_lbl.config(text="Edge devices: 0")
            self.pea_lbl.config(text="PEaaS devices: 0")
            self.cld_lbl.config(text="Cloud devices: 0")
            return
        for e in getattr(m, "entities", []):
            tier = self._device_tier(e)
            tcounts[tier] = tcounts.get(tier, 0) + 1
        self.edge_lbl.config(text=f"Edge devices: {tcounts.get('Edge',0)}")
        self.pea_lbl.config(text=f"PEaaS devices: {tcounts.get('PEaaS',0)}")
        self.cld_lbl.config(text=f"Cloud devices: {tcounts.get('Cloud',0)}")
    

    # ---------- utils ----------
    def _root_dir(self) -> str:
        import os
        return os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

    def _on_close(self):
        self._closed = True
        self.root.destroy()

    def _tick(self):
        if self._closed: return
        try:
            self._draw_content()
        except Exception as e:
            print("[LiveMap] frame error:", e)
        self.root.after(self.refresh_ms, self._tick)

    def start(self):
        self._tick()
        self.root.mainloop()
