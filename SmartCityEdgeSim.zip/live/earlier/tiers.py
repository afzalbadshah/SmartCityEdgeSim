# live/tiers.py

TIER_COLORS = {
    "Edge":    "#2563eb",  # blue
    "PEaaS":   "#ea580c",  # orange
    "Cloud":   "#16a34a",  # green
    "Unknown": "#6b7280",  # gray
}

SERVER_PALETTE = [
    "#2563eb", "#ef4444", "#10b981", "#f59e0b", "#8b5cf6",
    "#06b6d4", "#dc2626", "#22c55e", "#eab308", "#3b82f6",
    "#a855f7", "#f97316", "#14b8a6", "#84cc16", "#f43f5e",
]

def norm_tier_token(token: str) -> str:
    t = (token or "").strip().lower()
    if t in {"edge", "vehicular", "vehicularedge", "ve", "bsedge", "edgebs"}:
        return "Edge"
    if t in {"peaas", "peas", "regional", "rc", "region"}:
        return "PEaaS"
    if t in {"cloud", "cc"}:
        return "Cloud"
    return "Unknown"

def tier_from_server_name(name: str) -> str:
    return norm_tier_token((name or "").split("_", 1)[0])

def tier_from_server_obj(srv) -> str:
    name = getattr(srv, "name", "") or ""
    t = tier_from_server_name(name)
    if t != "Unknown":
        return t
    tier_attr = getattr(srv, "tier", None)
    if isinstance(tier_attr, str):
        return norm_tier_token(tier_attr)
    return "Unknown"
