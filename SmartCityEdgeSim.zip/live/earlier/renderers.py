# live/renderers.py
import os
import math
import tkinter as tk
from typing import Dict, List, Tuple, Optional

from .tiers import TIER_COLORS, SERVER_PALETTE, tier_from_server_obj

PAD        = 24
ICON_SIZE  = 22
DEVICE_R   = 3
GRID_SNAP  = 3  # px; bucket to detect near-overlaps

def _srv_key(srv) -> str:
    return f"{getattr(srv, 'name', 'srv')}#{getattr(srv, 'id', None) or id(srv)}"

class Assets:
    def __init__(self, base_dir: str):
        self.assets_dir = os.path.join(base_dir, "assets")
        if not os.path.isdir(self.assets_dir):
            self.assets_dir = os.path.join(os.path.dirname(__file__), "assets")
        self.edge   = self._load("edge")
        self.peaas  = self._load("regional") or self._load("peaas")
        self.cloud  = self._load("cloud")
        self.by_tier = {"Edge": self.edge, "PEaaS": self.peaas, "Cloud": self.cloud}

    def _load(self, name: str):
        p = os.path.join(self.assets_dir, f"{name}.png")
        if not os.path.isfile(p): return None
        try:
            img = tk.PhotoImage(file=p)
            fx = max(1, img.width()  // ICON_SIZE)
            fy = max(1, img.height() // ICON_SIZE)
            return img.subsample(fx, fy) if (fx > 1 or fy > 1) else img
        except Exception:
            return None


class Layout:
    """Transforms between simulation coords and canvas pixels, live-sized."""
    def __init__(self, canvas: tk.Canvas, xmin: float, xmax: float, ymin: float, ymax: float):
        self.cv   = canvas
        self.xmin = xmin; self.xmax = xmax
        self.ymin = ymin; self.ymax = ymax

    def sx(self, x: float) -> float:
        w = max(1, self.cv.winfo_width())
        if self.xmax == self.xmin: return PAD
        return PAD + (x - self.xmin) * (w - 2*PAD) / (self.xmax - self.xmin)

    def sy(self, y: float) -> float:
        h = max(1, self.cv.winfo_height())
        if self.ymax == self.ymin: return PAD
        return h - PAD - (y - self.ymin) * (h - 2*PAD) / (self.ymax - self.ymin)

    def inv_sx(self, cx: float) -> float:
        w = max(1, self.cv.winfo_width())
        return self.xmin + (cx - PAD) * (self.xmax - self.xmin) / max(1.0, (w - 2*PAD))

    def inv_sy(self, cy: float) -> float:
        h = max(1, self.cv.winfo_height())
        return self.ymin + (h - PAD - cy) * (self.ymax - self.ymin) / max(1.0, (h - 2*PAD))

    def clamp_canvas(self, cx: float, cy: float) -> Tuple[float, float]:
        w, h = self.cv.winfo_width(), self.cv.winfo_height()
        return (min(max(PAD, cx), w - PAD), min(max(PAD, cy), h - PAD))


class ServerRenderer:
    """Draw servers, allow drag in Setup, resolve near-overlaps, persist positions."""
    def __init__(self, canvas: tk.Canvas, layout: Layout, assets: Assets):
        self.cv = canvas
        self.ly = layout
        self.assets = assets

        self.server_colors: Dict[str, str] = {}
        self.ring_items:   Dict[str, int]  = {}
        self.icon_items:   Dict[str, int]  = {}
        self.label_items:  Dict[str, int]  = {}
        self.label_bg:     Dict[str, int]  = {}

        self.drag_enabled = False
        self._drag_key: Optional[str] = None
        self._drag_dx = 0.0
        self._drag_dy = 0.0

        self._servers_ref: List[object] = []  # updated on each draw()

    def assign_palette(self, servers: List[object]):
        self.server_colors.clear()
        for i, s in enumerate(servers):
            self.server_colors[_srv_key(s)] = SERVER_PALETTE[i % len(SERVER_PALETTE)]

    def _compute_positions(self, servers: List[object]) -> Dict[str, Tuple[float,float]]:
        buckets: Dict[Tuple[int,int], List[Tuple[str,float,float]]] = {}
        pos: Dict[str, Tuple[float,float]] = {}
        for s in servers:
            x, y = getattr(s, "x", None), getattr(s, "y", None)
            if x is None or y is None: continue
            cx, cy = self.ly.sx(float(x)), self.ly.sy(float(y))
            ix, iy = int(round(cx/GRID_SNAP))*GRID_SNAP, int(round(cy/GRID_SNAP))*GRID_SNAP
            buckets.setdefault((ix,iy), []).append((_srv_key(s), cx, cy))

        for (ix,iy), items in buckets.items():
            if len(items) == 1:
                k,cx,cy = items[0]; pos[k] = (cx,cy); continue
            R = 14.0
            for j,(k,cx,cy) in enumerate(items):
                ang = 2*math.pi*j/len(items)
                pos[k] = (ix + R*math.cos(ang), iy + R*math.sin(ang))
        return pos

    def _tag(self, key: str) -> str:
        return f"srv:{key}"

    def enable_drag(self, enable: bool):
        self.drag_enabled = bool(enable)

    # ----- mouse handlers -----
    def bind_handlers(self):
        self.cv.tag_bind("srv", "<ButtonPress-1>",  self._on_down)
        self.cv.tag_bind("srv", "<B1-Motion>",      self._on_move)
        self.cv.tag_bind("srv", "<ButtonRelease-1>",self._on_up)

    def _find_server_by_key(self, key: str):
        for s in self._servers_ref:
            if _srv_key(s) == key:
                return s
        return None

    def _on_down(self, evt):
        if not self.drag_enabled: return
        items = self.cv.find_withtag("current")
        if not items: return
        for key, item in self.icon_items.items():
            if item == items[0]:
                self._drag_key = key
                x0,y0 = self.cv.coords(item)
                self._drag_dx, self._drag_dy = x0 - evt.x, y0 - evt.y
                return

    def _on_move(self, evt):
        if not self.drag_enabled or not self._drag_key: return
        cx, cy = self.ly.clamp_canvas(evt.x + self._drag_dx, evt.y + self._drag_dy)
        self._move_drawn(self._drag_key, cx, cy)
        # Persist back into server object (no reset button needed)
        srv = self._find_server_by_key(self._drag_key)
        if srv is not None:
            setattr(srv, "x", float(self.ly.inv_sx(cx)))
            setattr(srv, "y", float(self.ly.inv_sy(cy)))

    def _on_up(self, _evt):
        self._drag_key = None

    def _move_drawn(self, key: str, cx: float, cy: float):
        if key in self.icon_items:
            iid = self.icon_items[key]
            if self.cv.type(iid) == "image":
                self.cv.coords(iid, cx, cy)
            else:
                size = 12
                self.cv.coords(iid, cx - size, cy - size, cx + size, cy + size)
        if key in self.ring_items:
            r = 16
            self.cv.coords(self.ring_items[key], cx - r, cy - r, cx + r, cy + r)
        if key in self.label_items and key in self.label_bg:
            txt = self.label_items[key]
            self.cv.coords(txt, cx, cy - 18)
            x1,y1,x2,y2 = self.cv.bbox(txt)
            self.cv.coords(self.label_bg[key], x1 - 4, y1 - 2, x2 + 4, y2 + 2)
            self.cv.tag_raise(txt, self.label_bg[key])

    # ----- draw -----
    def draw(self, servers: List[object]):
        self._servers_ref = servers
        if not servers: return
        pos = self._compute_positions(servers)
        order = sorted(servers, key=lambda s: {"Edge":0,"PEaaS":1,"Cloud":2}.get(tier_from_server_obj(s), 99))
        for srv in order:
            key  = _srv_key(srv)
            name = getattr(srv, "name", "")
            if key not in pos:
                x,y = getattr(srv,"x",None), getattr(srv,"y",None)
                if x is None or y is None: continue
                cx, cy = self.ly.sx(float(x)), self.ly.sy(float(y))
            else:
                cx, cy = pos[key]

            tier = tier_from_server_obj(srv)
            ring_color = TIER_COLORS.get(tier, "#9ca3af")
            icon = self.assets.by_tier.get(tier)

            # Ring
            r = 16
            if key not in self.ring_items:
                oid = self.cv.create_oval(cx - r, cy - r, cx + r, cy + r,
                                          outline=ring_color, width=2, tags=("srv", self._tag(key)))
                self.ring_items[key] = oid
            else:
                self.cv.coords(self.ring_items[key], cx - r, cy - r, cx + r, cy + r)

            # Icon
            if key not in self.icon_items:
                if icon:
                    iid = self.cv.create_image(cx, cy, image=icon, tags=("srv", self._tag(key)))
                else:
                    size = 12
                    iid = self.cv.create_rectangle(cx - size, cy - size, cx + size, cy + size,
                                                   fill=ring_color, outline="", tags=("srv", self._tag(key)))
                self.icon_items[key] = iid
            else:
                iid = self.icon_items[key]
                if self.cv.type(iid) == "image":
                    self.cv.coords(iid, cx, cy)
                else:
                    size = 12
                    self.cv.coords(iid, cx - size, cy - size, cx + size, cy + size)

            # Label + bubble bg
            if key not in self.label_items:
                txt = self.cv.create_text(cx, cy - 18, text=name, font=("Segoe UI", 9), fill="#111827", tags=("srv", self._tag(key)))
                x1,y1,x2,y2 = self.cv.bbox(txt)
                bg = self.cv.create_rectangle(x1 - 4, y1 - 2, x2 + 4, y2 + 2, fill="#ffffff", outline="#e5e7eb")
                self.cv.tag_raise(txt, bg)
                self.label_items[key] = txt
                self.label_bg[key]    = bg
            else:
                txt = self.label_items[key]
                self.cv.coords(txt, cx, cy - 18)
                x1,y1,x2,y2 = self.cv.bbox(txt)
                self.cv.coords(self.label_bg[key], x1 - 4, y1 - 2, x2 + 4, y2 + 2)
                self.cv.tag_raise(txt, self.label_bg[key])


class DeviceRenderer:
    def __init__(self, canvas: tk.Canvas, layout: Layout, color_fn):
        self.cv = canvas
        self.ly = layout
        self.color_fn = color_fn
        self.items: Dict[int,int] = {}

    @staticmethod
    def _extract_xy(ent) -> Tuple[Optional[float], Optional[float]]:
        pos = getattr(ent, "position", None)
        if isinstance(pos, (list, tuple)) and len(pos) >= 2: return float(pos[0]), float(pos[1])
        if isinstance(pos, dict):
            if "x" in pos and "y" in pos: return float(pos["x"]), float(pos["y"])
            if "X" in pos and "Y" in pos: return float(pos["X"]), float(pos["Y"])
        for xx, yy in [("x", "y"), ("X", "Y")]:
            if hasattr(pos, xx) and hasattr(pos, yy): return float(getattr(pos, xx)), float(getattr(pos, yy))
        if hasattr(ent, "x") and hasattr(ent, "y"): return float(getattr(ent, "x")), float(getattr(ent, "y"))
        if pos is not None: v=float(pos); return v,v
        return None, None

    def draw(self, entities: List[object]):
        if not entities: return
        r = DEVICE_R
        for e in entities:
            ent_id = getattr(e, "id", None)
            x,y = self._extract_xy(e)
            if ent_id is None or x is None or y is None: continue
            cx, cy = self.ly.sx(x), self.ly.sy(y)
            fill = self.color_fn(e)
            if ent_id not in self.items:
                self.items[ent_id] = self.cv.create_oval(cx - r, cy - r, cx + r, cy + r, fill=fill, outline="")
            else:
                iid = self.items[ent_id]
                self.cv.coords(iid, cx - r, cy - r, cx + r, cy + r)
                self.cv.itemconfig(iid, fill=fill)
