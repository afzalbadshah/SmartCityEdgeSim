


SERVER_CONFIG = {
    "MEC": {
        "num_datacenters": 5,
        "cpu": 280_000,
        "memory": 3000_00,
        "storage": 8_000_00,
        "bandwidth": 164_000,
        "latency": 5,
        "cost": 0.00005,
        "tx_cost": 0.00002,
        "distance": 2_000,
        # Positions are simple 2D coordinates (arbitrary plane) used by mobility/propagation.
        "positions": [
            [1500.0, 1500.0],   # MEC_1  SW corner
            [8500.0, 1500.0],   # MEC_2  SE corner
            [5000.0, 5000.0],   # MEC_3  CENTER
            [1500.0, 8500.0],   # MEC_4  NW corner
            [8500.0, 8500.0],   # MEC_5  NE corner
        ],
    },
    "Metro": {
        "num_datacenters": 2,
        "cpu": 6_400_000,
        "memory": 10_240_000,
        "storage": 40_000_000,
        "bandwidth": 800_000,
        "latency": 50,
        "cost": 0.0001,
        "tx_cost": 0.000005,
        "distance": 200_000,
        "positions": [
            [2700.0, 5000.0],   # Metro_1  West side (offset from MEC_4)
            [7300.0, 5000.0],   # Metro_2  East side (offset from MEC_5)
        ],
    },
    "Cloud": {
        "num_datacenters": 1,
        "cpu": 10_080_0000,
        "memory": 8_064_0000,
        "storage": 151_200_0000,
        "bandwidth": 1_050_000,
        "latency": 300,
        "cost": 0.0002,
        "tx_cost": 0.000005,
        "distance": 2_000_000,
        "positions": [
            [40000.0, 40000.0],   # Cloud_1
        ],
    },
}

# WORKLOAD
WORKLOAD = {
    "start_devices": 10,
    "max_devices": 2000,
    "increment": 10,
    "data_per_device_kb": 10000,  # NOTE: Many metrics scale with this central knob.
    "profile": "default",
}

# SIMULATION
# ----------
# High-level toggles for what to print/log each round.
SIMULATION = {
    "rounds": 1,
    "print_cost": True,
    "print_congestion": True,
    "log_assignments": True,
}

# MOBILITY_CONFIG

# --- City area for smart city (meters) ---
CITY_AREA = {
    "xmin": 0.0, "xmax": 10000.0,
    "ymin": 0.0, "ymax": 10000.0,
}

# --- Backbone distance from BS/Metro to Cloud (meters) ---
BS_CLOUD_DISTANCE_M = 50_000.0

# --- Propagation speeds & scalers (used by metrics.calculate_propagation_delay_mobility) ---
WIRELESS_PROP_SPEED  = 3.0e8      # ~speed of light in air
WIRED_PROP_SPEED     = 2.0e8      # ~fiber
WIRELESS_DELAY_SCALE = 1000        # leave 1.0 unless you want to inflate/deflate
WIRED_DELAY_SCALE    = 100
OB_PROP_DELAY_MS = 0.20


MOBILITY_CONFIG = {
    "enabled": True,
    "apply_to_servers": False,        # infra is usually fixed; flip True if you really want it mobile
    "num_entities": 50,
    # BIGGER step → bigger per-round movement (5 s)
    "time_step_ms": 5000,
    "handover_latency_ms": 5,
    "handover_threshold_db": 3,
    # Smart city speeds (pedestrians/bikes/cars)
    "default_speed_m_s": 10.0,
    "speed_range": (3.0, 15.0),
    # Short pauses so we actually move most rounds
    "pause_time": (0.0, 0.5),

    # IMPORTANT: walk inside the 20 km city. Tie this to CITY_AREA so you don’t
    # accidentally leave it at an old 0..1000 box.
    "area": CITY_AREA,
}
