"""
SmartCityEdgeSimPy — Educational Release

Mobility-aware metrics with full backward-compatibility:
- If MOBILITY_CONFIG["enabled"] == False → legacy behavior.
- If True:
    MEC   : onboard only.
    Metro  : onboard + wireless (vehicle ↔ Metro/BS) using task.distance_to_bs if available.
    Cloud  : onboard + wireless (vehicle ↔ Metro/BS) + wired (BS ↔ Cloud backbone).

NOTE: We keep original function names to minimize refactors across the codebase.
"""

import math
import statistics

# Core config objects
from config.config import SERVER_CONFIG, WORKLOAD
# Mobility config may not exist in older trees; fall back to disabled.
try:
    from config.config import MOBILITY_CONFIG
except Exception:
    MOBILITY_CONFIG = {"enabled": False}

# Access constants like OB/VE_PROP_DELAY_MS, WIRELESS_PROP_SPEED, etc.
import config.config as cfg

# ------------------------------------------------------------------
# Utility
# ------------------------------------------------------------------

def extract_base_layer(layer_name: str) -> str:
    """
    Turn labels like 'MEC_1' or 'Metro-3' into 'MEC' / 'Metro' / 'Cloud'.
    If no delimiter, return as-is.
    """
    if not isinstance(layer_name, str):
        return str(layer_name)
    head = layer_name.replace('-', '_').split('_')[0]
    head_u = head.upper()
    if head_u.startswith("MEC"):    return "MEC"
    if head_u.startswith("Metro"):   return "Metro"
    if head_u.startswith("CLOUD"):   return "Cloud"
    return head

# ------------------------------------------------------------------
# Cost Metrics
# ------------------------------------------------------------------

def calculate_transmission_cost(data_kb, tx_rate):
    """Cost = data (KB) * rate (per KB)"""
    return round(float(data_kb) * float(tx_rate), 4)

def calculate_processing_cost(cpu_demand, processing_rate):
    """Processing cost = cpu_demand * processing_rate"""
    return round(float(cpu_demand) * float(processing_rate), 6)

def calculate_total_cost(data_kb, cpu_demand, tx_rate, proc_rate):
    """Total cost = transmission cost + processing cost"""
    tx_cost   = calculate_transmission_cost(data_kb, tx_rate)
    proc_cost = calculate_processing_cost(cpu_demand, proc_rate)
    return round(tx_cost + proc_cost, 4)

# ------------------------------------------------------------------
# Delay helpers (mobility-aware)
# ------------------------------------------------------------------

def _wireless_delay_ms(distance_m: float) -> float:
    """
    Vehicle <-> Base Station hop delay (ms).
    """
    c_air   = float(getattr(cfg, "WIRELESS_PROP_SPEED", 3.0e8))   # m/s
    scale_w = float(getattr(cfg, "WIRELESS_DELAY_SCALE", 1.0))    # unitless
    base_ms = (float(distance_m) / max(c_air, 1e-9)) * 1e3
    base_ms *= scale_w
    #print(f"Wireless delay for {distance_m} m: {base_ms} ms")
    return base_ms

def _wired_delay_ms(distance_m: float) -> float:
    """
    Base Station <-> Cloud hop delay (ms).
    """
    c_fiber = float(getattr(cfg, "WIRED_PROP_SPEED", 2.0e8))      # m/s
    scale_l = float(getattr(cfg, "WIRED_DELAY_SCALE", 1.0))       # unitless
    base_ms = (float(distance_m) / max(c_fiber, 1e-9)) * 1e3
    #print(f"Wired delay for {distance_m} m: {base_ms} ms")
    return base_ms * scale_l

# ------------------------------------------------------------------
# Delay Metrics
# ------------------------------------------------------------------

def calculate_transmission_delay(data_kb, layer_name):
    """
    Transmission delay in milliseconds.
      seconds = (data_kb * 8) / bandwidth_kbps
      ms      = seconds * 1000
    """
    base = extract_base_layer(layer_name)
    bandwidth_kbps = float(SERVER_CONFIG[base]["bandwidth"])
    seconds = (float(data_kb) * 8.0) / max(bandwidth_kbps, 1e-9)
    return seconds * 1000.0

# metrics.py  (only the mobility-aware branch)
def calculate_propagation_delay(layer_name, task=None):
    base = extract_base_layer(layer_name)

    # Legacy path
    if not bool(MOBILITY_CONFIG.get("enabled", False)):
        distance_m = float(SERVER_CONFIG[base]["distance"])
        return round((distance_m / 2.0e8) * 1e3, 4)

    # Mobility-aware path
    onboard_ms = float(getattr(cfg, "OB_PROP_DELAY_MS",     # was VE_PROP_DELAY_MS
                               getattr(cfg, "VE_PROP_DELAY_MS", 0.20)))

    # Always include the device→BS/MEC wireless hop when a BS is involved
    wireless_ms = 0.0
    if base in ("MEC", "Metro", "Cloud"):
        dist_bs = float(getattr(task, "distance_to_bs",
                        SERVER_CONFIG.get("MEC", {}).get("distance", 2000.0)))
        wireless_ms = _wireless_delay_ms(dist_bs)

    # Backbone hop only for Cloud
    wired_ms = 0.0
    if base == "Cloud":
        d_backbone = float(getattr(cfg, "BS_CLOUD_DISTANCE_M", 50_000.0))
        wired_ms = _wired_delay_ms(d_backbone)

    return round(onboard_ms + wireless_ms + wired_ms, 4)



def calculate_total_delay(data_kb, layer_name, task=None):
    """
    Total delay (ms) = transmission + propagation
    (task is optional, only needed if mobility is enabled and distance_to_bs is used)
    """
    tx_delay   = calculate_transmission_delay(data_kb, layer_name)
    prop_delay = calculate_propagation_delay(layer_name, task=task)
    return round(tx_delay + prop_delay, 4)

# ------------------------------------------------------------------
# Energy Metrics
# ------------------------------------------------------------------
# ---------- Wireless distance helper (device → nearest MEC/WP) ----------
def _euclid(ax: float, ay: float, bx: float, by: float) -> float:
    dx = float(ax) - float(bx)
    dy = float(ay) - float(by)
    return math.hypot(dx, dy)

def _device_xy(task):
    if task is None:
        return 0.0, 0.0
    for kx, ky in (("x","y"), ("px","py"), ("pos_x","pos_y")):
        if hasattr(task, kx) and hasattr(task, ky):
            return float(getattr(task, kx)), float(getattr(task, ky))
    dev = getattr(task, "device", None)
    if dev is not None and hasattr(dev, "x") and hasattr(dev, "y"):
        return float(dev.x), float(dev.y)
    return 0.0, 0.0

def _nearest_mec_xy_for_device(dx: float, dy: float):
    mec_positions = SERVER_CONFIG.get("MEC", {}).get("positions", [])
    if not mec_positions:
        return 0.0, 0.0
    bx, by = min(mec_positions, key=lambda p: _euclid(dx, dy, p[0], p[1]))
    return float(bx), float(by)

def _wireless_distance_m(layer_name: str, task=None) -> float:
    """
    Distance of the *device* to its serving wireless point (nearest MEC).
    We intentionally do NOT use the old fixed 'distance' fields.
    """
    dx, dy = _device_xy(task)
    bx, by = _nearest_mec_xy_for_device(dx, dy)
    return _euclid(dx, dy, bx, by)

# ---------- Energy (device-side; uses wireless distance only) ----------
def calculate_energy_consumption(data_kb, base_energy_rate, distance_m, minor_distance_rate):
    energy_per_kb = float(base_energy_rate) + float(distance_m) * float(minor_distance_rate)
    return round(float(data_kb) * energy_per_kb, 6)

# Signatures unchanged; task is optional for backward compatibility.
def calculate_MEC_energy(data_kb, task=None):
    d_wireless = _wireless_distance_m("MEC_1", task)   # layer_name not used; keep API shape
    return calculate_energy_consumption(data_kb, 0.0000015, d_wireless, 0.000000001)

def calculate_Metro_energy(data_kb, task=None):
    d_wireless = _wireless_distance_m("Metro_1", task)
    return calculate_energy_consumption(data_kb, 0.0000030, d_wireless, 0.000000001)

def calculate_cloud_energy(data_kb, task=None):
    d_wireless = _wireless_distance_m("Cloud_1", task)
    return calculate_energy_consumption(data_kb, 0.0000050, d_wireless, 0.000000001)


def calculate_backbone_energy(data_kb, layer_name, task=None):
    """
    Infrastructure transport (BS/WP → Cloud) energy proxy — NOT device energy.
    Only meaningful for Cloud; returns 0 for MEC/Metro.
    """
    base = extract_base_layer(layer_name)
    if base != "Cloud":
        return 0.0
    # BS/WP = nearest MEC to the device
    dx, dy = _device_xy(task)
    bx, by = _nearest_mec_xy_for_device(dx, dy)
    # Cloud XY from positions[]
    positions = SERVER_CONFIG.get("Cloud", {}).get("positions", [[40000.0, 40000.0]])
    cx, cy = map(float, positions[0])
    d_backbone = _euclid(bx, by, cx, cy)
    return calculate_energy_consumption(data_kb, 0.0, d_backbone, 1e-9)



# ------------------------------------------------------------------
# Other Metrics
# ------------------------------------------------------------------

def calculate_response_time(latency, processing_time):
    """Response time (ms) = latency + processing_time"""
    return round(float(latency) + float(processing_time), 2)

def calculate_bandwidth_utilization(used_bandwidth_kb, total_bandwidth_kb):
    """Utilization (%) = used/total * 100"""
    total = float(total_bandwidth_kb)
    if total <= 0.0:
        return 0.0
    return round((float(used_bandwidth_kb) / total) * 100.0, 2)

def calculate_task_failure_rate(total_tasks, failed_tasks):
    """Failure rate (%) over a period."""
    total = int(total_tasks)
    if total == 0:
        return 0.0
    return round((int(failed_tasks) / total) * 100.0, 2)

# ------------------------------------------------------------------
# Resource Utilization
# ------------------------------------------------------------------

def calculate_cpu_utilization(available_cpu, total_cpu):
    """CPU utilization (%) from available vs total."""
    total = float(total_cpu)
    if total <= 0:
        return 0.0
    return round(100.0 * (1.0 - float(available_cpu) / total), 2)

def calculate_memory_utilization(available_memory, total_memory):
    """Memory utilization (%)."""
    total = float(total_memory)
    if total <= 0:
        return 0.0
    return round(100.0 * (1.0 - float(available_memory) / total), 2)

def calculate_storage_utilization(available_storage, total_storage):
    """Storage utilization (%)."""
    total = float(total_storage)
    if total <= 0:
        return 0.0
    return round(100.0 * (1.0 - float(available_storage) / total), 2)

def calculate_congestion(total_data_kb, bandwidth_kbps):
    """Simple congestion proxy (%)."""
    bw = float(bandwidth_kbps)
    if bw <= 0:
        return 0.0
    return round((float(total_data_kb) / bw) * 100.0, 2)

# ------------------------------------------------------------------
# Mobility Metrics (aggregated by the simulator/mobility manager)
# ------------------------------------------------------------------

def calculate_handover_count(metrics):
    return getattr(metrics, "total_handovers", 0)

def calculate_handover_success_ratio(metrics):
    attempts = float(getattr(metrics, "handover_attempts", 0))
    if attempts == 0:
        return 0.0
    return float(getattr(metrics, "total_handovers", 0)) / attempts

def calculate_extra_handover_delay(metrics):
    return float(getattr(metrics, "total_handover_delay_ms", 0.0))

def calculate_task_delay_increase(baseline_delays, ho_task_delays):
    """Mean(ho - base) across paired delays."""
    diffs = [float(ho) - float(base) for ho, base in zip(ho_task_delays, baseline_delays)]
    return statistics.mean(diffs) if diffs else 0.0

def calculate_avg_rss(metrics):
    """Average RSS; returns -inf if no samples."""
    samples = getattr(metrics, "rss_samples", [])
    return sum(samples) / len(samples) if samples else -math.inf

def calculate_coverage_outage_time(metrics):
    return float(getattr(metrics, "total_outage_time_ms", 0.0))

def calculate_task_drop_rate(metrics):
    total = int(getattr(metrics, "total_tasks", 0))
    if total == 0:
        return 0.0
    dropped = int(getattr(metrics, "dropped_tasks", 0))
    return dropped / total

def calculate_throughput_variation(metrics):
    ths = getattr(metrics, "throughputs", [])
    if not ths:
        return 0.0
    return max(ths) - min(ths)
