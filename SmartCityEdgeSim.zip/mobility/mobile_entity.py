"""
RegionalMECSimPy — Educational Release

Author: Dr. Afzal Badshah
Department of Software Engineering, University of Sargodha
Website: https://afzalbadshah.com/index.php/afzal-badshah/
LinkedIn: https://www.linkedin.com/in/afzal-badshah-phd-305b03164/
Discussion Forum: resp.afzalbadshah.com

Notes:
- Safe defaults for mobility config to avoid KeyError.
- Works with 1D or 2D positions and multiple mobility model APIs.
- Returns (server, ho_ms) from pick_best_bs for handover accounting.
"""

import math
from config.config import MOBILITY_CONFIG


class MobileEntity:
    """
    Represents a mobile node (device/vehicle).
    Position can be:
      - 1D float (legacy)
      - 2D (x, y) list/tuple
    """

    def __init__(self, entity_id, init_pos, speed):
        self.id = entity_id
        self.position = init_pos  # 1D float or 2D [x, y]
        self.speed = float(speed)

        # Serving / handover state
        self.attached_server = None
        self.last_handover_ms = 0.0

        # Safe defaults (avoid KeyError if config keys are missing)
        self.ho_latency = float(MOBILITY_CONFIG.get("handover_latency_ms", 5.0))
        self.ho_threshold_db = float(MOBILITY_CONFIG.get("handover_threshold_db", 3.0))

        # Mobility controller (e.g., RandomWaypoint). Set by simulator.
        self.mobility = None

        # Ensure x, y are always present for convenience
        if isinstance(self.position, (list, tuple)) and len(self.position) >= 2:
            self.x = float(self.position[0])
            self.y = float(self.position[1])
        else:
            # legacy 1D → map to (x, 0)
            self.x = float(self.position)
            self.y = 0.0

    # -------- convenience --------

    def set_mobility(self, model):
        """Attach a mobility model (RandomWaypoint, etc.)."""
        self.mobility = model

    def get_position(self):
        """Always return a 2D tuple (x, y)."""
        return float(self.x), float(self.y)

    # -------- movement & radio --------

    def move(self, dt_ms):
        """
        Advance position by dt_ms.
        - If 2D and a mobility model exists:
            * Prefer model.next_position(dt_ms)  -> (x, y)
            * Else fallback to model.step(dt_s)  -> (x, y)
        - If 1D (legacy) with no model: x += speed * dt_s
        """
        dt_s = float(dt_ms) / 1000.0

        if self.mobility is not None:
            # Try both possible APIs
            if hasattr(self.mobility, "next_position"):
                nx, ny = self.mobility.next_position(dt_ms)
            else:
                # Expect step(seconds) → (x, y)
                nx, ny = self.mobility.step(dt_s)
            self.x, self.y = float(nx), float(ny)
            self.position = [self.x, self.y]
            return self.position

        # No mobility model: keep legacy behavior
        if isinstance(self.position, (int, float, float)):
            # 1D drift
            self.x += self.speed * dt_s
            self.position = self.x
            # y stays 0
        else:
            # 2D but no model → stay put
            pass

        return self.position

    def signal_strength(self, server):
        """
        Basic path-loss style RSS (dB, higher is better).
        Uses Euclidean distance to server.x/server.y when available,
        falls back to |x - server.location| in 1D.
        """
        if isinstance(self.position, (list, tuple)):
            sx = float(getattr(server, "x", getattr(server, "location", 0.0)))
            sy = float(getattr(server, "y", 0.0))
            dx = float(self.x) - sx
            dy = float(self.y) - sy
            dist = math.hypot(dx, dy)
        else:
            dist = abs(float(self.x) - float(getattr(server, "location", 0.0)))

        d = max(1.0, dist)  # avoid log10(0)
        # Close-in ref ≈ -40 dB at 1 m, decay ~20log10(d)
        return max(-120.0, -40.0 - 20.0 * math.log10(d))

    # -------- serving cell selection / HO --------
    def pick_best_bs(self, servers):
        # Accept any list, but only consider MEC_* as real WPs
        candidates = [s for s in servers if str(getattr(s, "name", "")).startswith("MEC_")]
        if not candidates:
            # No MECs available → keep current attachment (no HO)
            return getattr(self, "attached_server", None), 0.0

        x, y = self.get_position()
        best = min(
            (s for s in candidates if hasattr(s, "x") and hasattr(s, "y")),
            key=lambda s: ((s.x - x)**2 + (s.y - y)**2),
        )
        dx, dy = (best.x - x), (best.y - y)
        return best, (dx*dx + dy*dy) ** 0.5



    

    def handover(self, new_server):
        """
        Perform the handover: switch attachment and remember the latency.
        """
        self.attached_server = new_server
        self.last_handover_ms = self.ho_latency
        return new_server
