"""
RegionalMECSimPy — Educational Release

Notes:
- Single-class manager that keeps metrics in a dict.
- Critical fixes:
  (1) write back ent.x/ent.y after mobility updates.
  (2) unpack (server, ho_ms) from pick_best_bs() and use ho_ms directly.
"""

import math
from copy import deepcopy
from config.config import MOBILITY_CONFIG


def _fallback_metric_defaults():
    return {
        "handover_count_step": 0,
        "handover_delay_step_ms": 0.0,
        "avg_pos_dispersion": 0.0,
        "total_handovers": 0,
        "handover_attempts": 0,
        "total_handover_delay_ms": 0.0,
        "rss_samples": [],
        "total_outage_time_ms": 0.0,
        "dropped_tasks": 0,
        "total_tasks": 0,
        "throughputs": [],
    }


class MobilityManager:
    def __init__(self, servers, devices=None):
        self.servers = servers
        self.entities = devices if devices is not None else []
        self.time_step_ms = MOBILITY_CONFIG.get("time_step_ms", 100)

        cfg_defaults = MOBILITY_CONFIG.get("metrics_defaults")
        self.metrics = deepcopy(cfg_defaults) if isinstance(cfg_defaults, dict) else _fallback_metric_defaults()

        for ent in self.entities:
            if not hasattr(ent, "last_handover_ms"):
                ent.last_handover_ms = 0.0

    # ---- helpers ----
    def _avg_position_dispersion(self) -> float:
        if not self.entities:
            return 0.0
        xs, ys = [], []
        for ent in self.entities:
            # use ent.x/ent.y (kept in sync with ent.position)
            xs.append(float(getattr(ent, "x", 0.0)))
            ys.append(float(getattr(ent, "y", 0.0)))
        cx = sum(xs) / len(xs)
        cy = sum(ys) / len(ys)
        return sum(math.hypot(x - cx, y - cy) for x, y in zip(xs, ys)) / len(xs)

    def _MEC_servers(self):
        return [s for s in self.servers if str(getattr(s, "name", "")).startswith("MEC_")]


    # ---- main API ----
    def update_all(self):
        dt_ms = self.time_step_ms
        step_ho_count = 0
        step_ho_delay_ms = 0.0

        # Servers (usually static)
        if MOBILITY_CONFIG.get("apply_to_servers", False):
            for srv in self.servers:
                if hasattr(srv, "mobility") and srv.mobility:
                    nx, ny = srv.mobility.next_position(dt_ms)
                    srv.x, srv.y = float(nx), float(ny)
                    srv.location = srv.x  # legacy 1D

        # Devices
        for ent in self.entities:
            if hasattr(ent, "mobility") and ent.mobility:
                nx, ny = ent.mobility.next_position(dt_ms)
                ent.position = [float(nx), float(ny)]
                ent.x, ent.y = float(nx), float(ny)
            else:
                ent.move(dt_ms)  # legacy 1D fallback updates ent.x

            # Best BS & handover accounting
            # MEC-only (real wireless)
            wireless = [s for s in self.servers if str(getattr(s, "name", "")).startswith("MEC_")]

            MEC_list = self._MEC_servers()
            best_bs, d = ent.pick_best_bs(MEC_list)

            new_bs, ho_ms = ent.pick_best_bs(wireless)

            ent.attached_server = new_bs
            ent.last_handover_ms = float(ho_ms)
            if ho_ms > 0.0:
                step_ho_count += 1
                step_ho_delay_ms += ho_ms

            # MEC-only enforcement (in case anything upstream set Metro/Cloud)
            if ent.attached_server is None or not str(getattr(ent.attached_server, "name", "")).startswith("MEC_"):
                fallback_bs, _ = ent.pick_best_bs(MEC_list)
                if fallback_bs is not None:
                    ent.attached_server = fallback_bs
    

        # Per-step snapshots
        self.metrics["handover_count_step"] = int(step_ho_count)
        self.metrics["handover_delay_step_ms"] = float(step_ho_delay_ms)
        self.metrics["avg_pos_dispersion"] = float(self._avg_position_dispersion())

        # Running totals
        self.metrics["total_handovers"] += int(step_ho_count)
        self.metrics["handover_attempts"] += len(self.entities)
        self.metrics["total_handover_delay_ms"] += float(step_ho_delay_ms)

        return step_ho_count, step_ho_delay_ms


    def get_metrics(self):
        return {
            "avg_pos": round(self.metrics.get("avg_pos_dispersion", 0.0), 2),
            "ho_count": self.metrics.get("handover_count_step", 0),
            "ho_delay": self.metrics.get("handover_delay_step_ms", 0.0),
        }
